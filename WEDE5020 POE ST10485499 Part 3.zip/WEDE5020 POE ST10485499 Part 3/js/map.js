/* ==========================================================================
   Interactive map (Leaflet + OpenStreetMap): bakery marker, "find my
   distance" using the browser's geolocation, and a directions link.
   Leaflet is loaded from a CDN on demand so the page works without it.
   ========================================================================== */
(function () {
  'use strict';
  var AH = window.AH;
  var holder = document.getElementById('bakery-map');
  if (!holder) { return; }

  var LEAFLET_JS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
  var LEAFLET_CSS = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
  var result = document.getElementById('map-result');
  var locateBtn = document.getElementById('locate-btn');
  var directions = document.getElementById('directions-link');
  directions.href = 'https://www.google.com/maps/dir/?api=1&destination=' + AH.config.lat + ',' + AH.config.lng;

  function haversine(a, b, c, d) {
    var R = 6371, rad = Math.PI / 180;
    var dLat = (c - a) * rad, dLng = (d - b) * rad;
    var h = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a * rad) * Math.cos(c * rad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * R * Math.asin(Math.sqrt(h));
  }

  function load(cb) {
    if (window.L) { return cb(); }
    var css = document.createElement('link'); css.rel = 'stylesheet'; css.href = LEAFLET_CSS; document.head.appendChild(css);
    var s = document.createElement('script'); s.src = LEAFLET_JS; s.async = true;
    s.onload = cb;
    s.onerror = function () {
      holder.innerHTML = '<div class="map-fallback"><p>The interactive map could not load. Use the directions link, or find us at ' + AH.escape(AH.config.address) + '.</p></div>';
    };
    document.head.appendChild(s);
  }

  function build() {
    var L = window.L;
    var map = L.map(holder, { scrollWheelZoom: false }).setView([AH.config.lat, AH.config.lng], 15);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    var icon = L.divIcon({ className: '', html: '<div class="map-pin"></div>', iconSize: [34, 34], iconAnchor: [17, 34], popupAnchor: [0, -32] });
    var marker = L.marker([AH.config.lat, AH.config.lng], { icon: icon, title: AH.config.businessName, alt: AH.config.businessName }).addTo(map);
    var s = AH.openStatus();
    marker.bindPopup('<strong>' + AH.escape(AH.config.businessName) + '</strong><br>' + AH.escape(AH.config.address) + '<br><em>' + AH.escape(s.label + ': ' + s.detail) + '</em>').openPopup();

    /* Wheel zoom only after the user clicks into the map (avoids scroll-trap). */
    map.on('focus', function () { map.scrollWheelZoom.enable(); });
    map.on('blur', function () { map.scrollWheelZoom.disable(); });

    var userMarker, line;
    locateBtn.addEventListener('click', function () {
      if (!navigator.geolocation) { result.hidden = false; result.textContent = 'Your browser does not support location. Use the directions link instead.'; return; }
      locateBtn.disabled = true; locateBtn.textContent = 'Finding you...';
      navigator.geolocation.getCurrentPosition(function (pos) {
        var la = pos.coords.latitude, ln = pos.coords.longitude;
        var km = haversine(la, ln, AH.config.lat, AH.config.lng);
        if (userMarker) { map.removeLayer(userMarker); map.removeLayer(line); }
        userMarker = L.circleMarker([la, ln], { radius: 9, color: '#fff', weight: 3, fillColor: '#17384d', fillOpacity: 1 }).addTo(map).bindTooltip('You are here');
        line = L.polyline([[la, ln], [AH.config.lat, AH.config.lng]], { color: '#a4531a', weight: 4, dashArray: '8 8' }).addTo(map);
        map.fitBounds(line.getBounds(), { padding: [50, 50] });
        result.hidden = false;
        result.textContent = 'You are about ' + (km < 1 ? Math.round(km * 1000) + ' m' : km.toFixed(1) + ' km') + ' from the bakery in a straight line.';
        locateBtn.disabled = false; locateBtn.textContent = 'Update my location';
      }, function () {
        result.hidden = false; result.textContent = 'We could not get your location. Allow location access, or use the directions link.';
        locateBtn.disabled = false; locateBtn.textContent = 'Show my distance';
      }, { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 });
    });
  }

  /* Load the map when it scrolls near the viewport (saves data and speeds up first paint). */
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting) { io.disconnect(); load(build); }
    }, { rootMargin: '300px' });
    io.observe(holder);
  } else { load(build); }
})();
