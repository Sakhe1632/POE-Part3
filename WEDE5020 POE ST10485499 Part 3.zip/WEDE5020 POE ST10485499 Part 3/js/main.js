/* ==========================================================================
   Artisan's Hearth Bakery - core behaviour used on every page
   - mobile navigation, sticky header, back-to-top
   - live "open now" status (Africa/Johannesburg time)
   - enquiry basket (localStorage) + header badge
   - accessible accordion and tabs components
   - toast notifications, share buttons, journal "load more"
   ========================================================================== */
(function () {
  'use strict';
  var AH = (window.AH = window.AH || {});
  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };
  AH.$ = $; AH.$$ = $$;

  /* ---- Safe localStorage ------------------------------------------------- */
  var store = {
    get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* private mode */ } }
  };
  AH.store = store;

  /* ---- Time helpers (always South African time, whatever the visitor's) -- */
  AH.saNow = function (base) {
    var d = base || new Date();
    var parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: AH.config.timezone, year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', hourCycle: 'h23', weekday: 'short'
    }).formatToParts(d);
    var o = {};
    parts.forEach(function (p) { o[p.type] = p.value; });
    var wd = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[o.weekday];
    return {
      iso: o.year + '-' + o.month + '-' + o.day,
      year: +o.year, month: +o.month, day: +o.day,
      hour: +o.hour, minute: +o.minute, weekday: wd
    };
  };

  AH.isClosedDay = function (iso, weekday) {
    return !AH.hours[weekday] || AH.holidays.indexOf(iso) !== -1;
  };

  /** Parse 'YYYY-MM-DD' into weekday (0-6) without timezone drift. */
  AH.weekdayOf = function (iso) {
    var p = iso.split('-');
    return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay();
  };

  AH.addDays = function (iso, n) {
    var p = iso.split('-');
    var d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2] + n));
    return d.toISOString().slice(0, 10);
  };

  AH.formatDate = function (iso) {
    var p = iso.split('-');
    var d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2]));
    var f = function (o) { return new Intl.DateTimeFormat('en-GB', Object.assign({ timeZone: 'UTC' }, o)).format(d); };
    return f({ weekday: 'long' }) + ' ' + (+p[2]) + ' ' + f({ month: 'long' });
  };

  /** First open day on or after the ISO date. */
  AH.nextOpenDay = function (iso) {
    var guard = 0;
    while (AH.isClosedDay(iso, AH.weekdayOf(iso)) && guard < 14) { iso = AH.addDays(iso, 1); guard++; }
    return iso;
  };

  function hourLabel(h) { return (h % 12 === 0 ? 12 : h % 12) + (h < 12 ? ' am' : ' pm'); }

  /** Returns {open, label, detail} for the current moment. */
  AH.openStatus = function () {
    var n = AH.saNow();
    var slot = AH.isClosedDay(n.iso, n.weekday) ? null : AH.hours[n.weekday];
    var mins = n.hour * 60 + n.minute;
    if (slot && mins >= slot[0] * 60 && mins < slot[1] * 60) {
      var left = slot[1] * 60 - mins;
      var soon = left <= 60;
      return { open: true, label: 'Open now', detail: soon ? 'Closing soon, at ' + hourLabel(slot[1]) : 'Open until ' + hourLabel(slot[1]) };
    }
    if (slot && mins < slot[0] * 60) {
      return { open: false, label: 'Opening soon', detail: 'Opens today at ' + hourLabel(slot[0]) };
    }
    var next = AH.nextOpenDay(AH.addDays(n.iso, 1));
    var nextSlot = AH.hours[AH.weekdayOf(next)];
    var tomorrow = next === AH.addDays(n.iso, 1);
    return { open: false, label: 'Closed', detail: 'Opens ' + (tomorrow ? 'tomorrow' : AH.formatDate(next)) + ' at ' + hourLabel(nextSlot[0]) };
  };

  /* ---- Toast ------------------------------------------------------------- */
  AH.toast = function (message) {
    var host = $('#toast');
    if (!host) { return; }
    host.textContent = message;
    host.classList.add('is-visible');
    window.clearTimeout(AH._toastTimer);
    AH._toastTimer = window.setTimeout(function () { host.classList.remove('is-visible'); }, 3200);
  };

  /* ---- Enquiry basket ---------------------------------------------------- */
  AH.basket = (function () {
    var KEY = 'ah-basket-v1';
    var items = [];
    try { items = JSON.parse(store.get(KEY) || '[]'); } catch (e) { items = []; }
    items = items.filter(function (i) { return i && AH.getProduct(i.id) && i.qty > 0; });

    function save() {
      store.set(KEY, JSON.stringify(items));
      document.dispatchEvent(new CustomEvent('basket:change', { detail: items.slice() }));
      renderBadge();
    }
    function find(id) { for (var i = 0; i < items.length; i++) { if (items[i].id === id) { return items[i]; } } return null; }
    function count() { return items.reduce(function (s, i) { return s + i.qty; }, 0); }
    function renderBadge() {
      $$('[data-basket-count]').forEach(function (el) {
        var c = count();
        el.textContent = c;
        el.hidden = c === 0;
        el.setAttribute('aria-label', c + (c === 1 ? ' item' : ' items') + ' in your enquiry');
      });
    }
    return {
      all: function () { return items.slice(); },
      count: count,
      has: function (id) { return !!find(id); },
      add: function (id, qty) {
        var it = find(id);
        if (it) { it.qty = Math.min(50, it.qty + (qty || 1)); } else { items.push({ id: id, qty: qty || 1 }); }
        save();
      },
      set: function (id, qty) {
        var it = find(id);
        if (!it) { return; }
        if (qty <= 0) { items = items.filter(function (i) { return i.id !== id; }); } else { it.qty = Math.min(50, qty); }
        save();
      },
      remove: function (id) { items = items.filter(function (i) { return i.id !== id; }); save(); },
      clear: function () { items = []; save(); },
      render: renderBadge
    };
  })();

  /* ---- Header: mobile nav, scroll state, status pill ---------------------- */
  function initHeader() {
    var header = $('.site-header');
    var toggle = $('.nav-toggle');
    var nav = $('#site-nav');
    if (toggle && nav) {
      var setOpen = function (open) {
        toggle.setAttribute('aria-expanded', String(open));
        nav.classList.toggle('is-open', open);
        toggle.querySelector('.sr-only').textContent = open ? 'Close menu' : 'Open menu';
      };
      toggle.addEventListener('click', function () { setOpen(toggle.getAttribute('aria-expanded') !== 'true'); });
      document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && nav.classList.contains('is-open')) { setOpen(false); toggle.focus(); }
      });
      document.addEventListener('click', function (e) {
        if (nav.classList.contains('is-open') && !nav.contains(e.target) && !toggle.contains(e.target)) { setOpen(false); }
      });
    }
    if (header) {
      var onScroll = function () { header.classList.toggle('is-scrolled', window.scrollY > 8); };
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }
    AH.basket.render();
  }

  function initStatus() {
    var els = $$('[data-open-status]');
    if (!els.length) { return; }
    function paint() {
      var s = AH.openStatus();
      els.forEach(function (el) {
        el.classList.toggle('is-open', s.open);
        var label = el.querySelector('[data-status-label]');
        var detail = el.querySelector('[data-status-detail]');
        if (label) { label.textContent = s.label; }
        if (detail) { detail.textContent = s.detail; }
      });
    }
    paint();
    window.setInterval(paint, 60000);
  }

  function initBackToTop() {
    var btn = $('#back-to-top');
    if (!btn) { return; }
    window.addEventListener('scroll', function () { btn.classList.toggle('is-visible', window.scrollY > 700); }, { passive: true });
    btn.addEventListener('click', function () {
      var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
    });
  }

  function initYear() {
    $$('[data-year]').forEach(function (el) { el.textContent = new Date().getFullYear(); });
    $$('[data-years-baking]').forEach(function (el) { el.textContent = new Date().getFullYear() - AH.config.foundedYear; });
  }

  /* ---- Accordion --------------------------------------------------------- */
  AH.initAccordions = function (root) {
    $$('[data-accordion]', root).forEach(function (acc) {
      if (acc.dataset.ready) { return; }
      acc.dataset.ready = '1';
      var single = acc.hasAttribute('data-single');
      var triggers = $$('.accordion__trigger', acc);
      function setState(trigger, open) {
        var panel = document.getElementById(trigger.getAttribute('aria-controls'));
        trigger.setAttribute('aria-expanded', String(open));
        panel.classList.toggle('is-open', open);
        if (open) { panel.removeAttribute('inert'); } else { panel.setAttribute('inert', ''); }
      }
      triggers.forEach(function (t) {
        setState(t, t.getAttribute('aria-expanded') === 'true');
        t.addEventListener('click', function () {
          var willOpen = t.getAttribute('aria-expanded') !== 'true';
          if (single && willOpen) { triggers.forEach(function (o) { if (o !== t) { setState(o, false); } }); }
          setState(t, willOpen);
        });
        t.addEventListener('keydown', function (e) {
          var i = triggers.indexOf(t);
          var target = null;
          if (e.key === 'ArrowDown') { target = triggers[(i + 1) % triggers.length]; }
          if (e.key === 'ArrowUp') { target = triggers[(i - 1 + triggers.length) % triggers.length]; }
          if (e.key === 'Home') { target = triggers[0]; }
          if (e.key === 'End') { target = triggers[triggers.length - 1]; }
          if (target) { e.preventDefault(); target.focus(); }
        });
      });
    });
  };

  /* ---- Tabs (WAI-ARIA tabs pattern) --------------------------------------- */
  AH.initTabs = function (root) {
    $$('[data-tabs]', root).forEach(function (wrap) {
      if (wrap.dataset.ready) { return; }
      wrap.dataset.ready = '1';
      var tabs = $$('[role="tab"]', wrap);
      var panels = $$('[role="tabpanel"]', wrap);
      function select(tab, focus) {
        tabs.forEach(function (t, i) {
          var on = t === tab;
          t.setAttribute('aria-selected', String(on));
          t.tabIndex = on ? 0 : -1;
          panels[i].hidden = !on;
        });
        if (focus) { tab.focus(); }
      }
      tabs.forEach(function (tab, i) {
        tab.addEventListener('click', function () { select(tab, false); });
        tab.addEventListener('keydown', function (e) {
          var n = null;
          if (e.key === 'ArrowRight') { n = tabs[(i + 1) % tabs.length]; }
          if (e.key === 'ArrowLeft') { n = tabs[(i - 1 + tabs.length) % tabs.length]; }
          if (e.key === 'Home') { n = tabs[0]; }
          if (e.key === 'End') { n = tabs[tabs.length - 1]; }
          if (n) { e.preventDefault(); select(n, true); }
        });
      });
      var hash = window.location.hash.slice(1);
      var start = tabs.filter(function (t) { return t.getAttribute('aria-controls') === hash; })[0] || tabs[0];
      select(start, false);
    });
  };

  /* ---- Share buttons ------------------------------------------------------ */
  function initShare() {
    $$('[data-share]').forEach(function (box) {
      var url = window.location.href.split('#')[0];
      var title = document.title;
      var text = encodeURIComponent(title + ' ' + url);
      var wa = $('[data-share-whatsapp]', box);
      var fb = $('[data-share-facebook]', box);
      var x = $('[data-share-x]', box);
      if (wa) { wa.href = 'https://wa.me/?text=' + text; }
      if (fb) { fb.href = 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url); }
      if (x) { x.href = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(title) + '&url=' + encodeURIComponent(url); }
      var copy = $('[data-share-copy]', box);
      if (copy) {
        copy.addEventListener('click', function () {
          var done = function () { AH.toast('Link copied to clipboard'); };
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(done, function () { AH.toast('Copy failed. Select the address bar instead.'); });
          } else { AH.toast('Copy is not available in this browser.'); }
        });
      }
      var native = $('[data-share-native]', box);
      if (native) {
        if (navigator.share) {
          native.hidden = false;
          native.addEventListener('click', function () { navigator.share({ title: title, url: url }).catch(function () {}); });
        }
      }
    });
  }

  /* ---- Home: "today at the oven" board ------------------------------------ */
  function initOvenBoard() {
    var list = $('#oven-list');
    if (!list) { return; }
    var n = AH.saNow();
    var ids = AH.todaysBake[n.weekday];
    var dayName = AH.formatDate(n.iso).split(' ')[0];
    var heading = $('#oven-day');
    if (!ids || AH.isClosedDay(n.iso, n.weekday)) {
      if (heading) { heading.textContent = 'The oven is resting today'; }
      list.innerHTML = '<li class="oven__rest">We are closed today. Pre-order below and collect fresh bread when we reopen.</li>';
      return;
    }
    if (heading) { heading.textContent = 'On the oven this ' + dayName; }
    list.innerHTML = ids.map(function (id) {
      var p = AH.getProduct(id);
      return '<li><a href="products.html?q=' + encodeURIComponent(p.name) + '">' + AH.escape(p.name) + '</a><span>' + AH.formatRand(p.price) + '</span></li>';
    }).join('');
  }

  /* ---- Home: journal with "load more" ------------------------------------- */
  function initJournal() {
    var host = $('#journal-list');
    var btn = $('#journal-more');
    if (!host || !btn) { return; }
    var shown = 0, step = 2;
    function postHtml(p) {
      var date = new Intl.DateTimeFormat('en-ZA', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(p.date + 'T00:00:00Z'));
      return '<article class="note">' +
        '<p class="note__meta"><span>' + AH.escape(p.topic) + '</span><time datetime="' + p.date + '">' + date + '</time></p>' +
        '<h3>' + AH.escape(p.title) + '</h3>' +
        '<p>' + AH.escape(p.body) + '</p>' +
        '<a class="text-link" href="' + p.link.href + '">' + AH.escape(p.link.text) + '</a></article>';
    }
    function showMore() {
      var next = AH.posts.slice(shown, shown + step);
      var firstNew = null;
      next.forEach(function (p) {
        var wrap = document.createElement('div');
        wrap.innerHTML = postHtml(p);
        var el = wrap.firstChild;
        if (shown > 0) { el.classList.add('is-new'); }
        host.appendChild(el);
        if (!firstNew) { firstNew = el; }
      });
      shown += next.length;
      var left = AH.posts.length - shown;
      btn.hidden = left <= 0;
      btn.textContent = 'Load more notes (' + left + ' left)';
      if (shown > step && firstNew) {
        var h = firstNew.querySelector('h3'); h.tabIndex = -1; h.focus({ preventScroll: true });
        AH.toast(next.length + ' more notes loaded');
      }
    }
    btn.addEventListener('click', showMore);
    showMore();
  }

  /* ---- Contact: highlight today's row in the hours table ------------------ */
  function initHoursTable() {
    var row = $('tr[data-day="' + AH.saNow().weekday + '"]');
    if (row) { row.classList.add('is-today'); }
  }

  document.addEventListener('DOMContentLoaded', function () {
    initHoursTable();
    initHeader(); initStatus(); initBackToTop(); initYear();
    AH.initAccordions(); AH.initTabs(); initShare(); initOvenBoard(); initJournal();
  });
})();
