/* ==========================================================================
   Forms: validation engine, enquiry processing (quote + availability),
   contact form (compiled email) and AJAX submission.
   ========================================================================== */
(function () {
  'use strict';
  var AH = window.AH;
  var $ = AH.$, $$ = AH.$$;

  /* ---- Validators --------------------------------------------------------- */
  var V = {
    required: function (msg) { return function (v) { return v.trim() ? '' : msg; }; },
    name: function (v) {
      v = v.trim();
      if (!v) { return 'Enter your full name.'; }
      if (v.length < 2) { return 'Your name needs at least 2 characters.'; }
      if (v.length > 60) { return 'Keep your name under 60 characters.'; }
      if (!/^[A-Za-zÀ-ɏ][A-Za-zÀ-ɏ '’.\-]*$/.test(v)) { return 'Use letters, spaces, hyphens or apostrophes only.'; }
      return '';
    },
    email: function (v) {
      v = v.trim();
      if (!v) { return 'Enter your email address.'; }
      if (v.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) { return 'Enter an email address like name@example.com.'; }
      return '';
    },
    phoneOptional: function (v) {
      v = v.trim();
      if (!v) { return ''; }
      var d = v.replace(/[\s\-().]/g, '');
      if (!/^(?:\+27|0027|0)[1-9]\d{8}$/.test(d)) { return 'Enter a South African number like 012 345 6789 or +27 82 123 4567.'; }
      return '';
    },
    phoneRequired: function (v) { return v.trim() ? V.phoneOptional(v) : 'Enter a phone number so we can call you.'; },
    select: function (msg) { return function (v) { return v ? '' : msg; }; },
    text: function (min, max, label) {
      return function (v) {
        v = v.trim();
        if (!v) { return 'Enter ' + label + '.'; }
        if (v.length < min) { return label.charAt(0).toUpperCase() + label.slice(1) + ' needs at least ' + min + ' characters (you have ' + v.length + ').'; }
        if (v.length > max) { return 'Keep ' + label + ' under ' + max + ' characters.'; }
        return '';
      };
    },
    checked: function (msg) { return function (v, el) { return el.checked ? '' : msg; }; }
  };

  /* ---- Generic form controller ------------------------------------------- */
  function FormController(form, rules, opts) {
    var self = this;
    this.form = form;
    this.rules = rules;
    this.summary = $('.form-summary', form);
    this.touched = {};
    form.setAttribute('novalidate', '');

    Object.keys(rules).forEach(function (name) {
      var el = form.elements[name];
      if (!el) { return; }
      var nodes = el.length && !el.tagName ? Array.prototype.slice.call(el) : [el];
      nodes.forEach(function (n) {
        n.addEventListener('blur', function () { self.touched[name] = true; self.check(name); });
        n.addEventListener('input', function () { if (self.touched[name]) { self.check(name); } });
        n.addEventListener('change', function () { self.touched[name] = true; self.check(name); });
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var bad = self.checkAll();
      if (bad.length) { self.showSummary(bad); return; }
      self.hideSummary();
      opts.onValid(self.values(), self);
    });
    form.addEventListener('reset', function () {
      window.setTimeout(function () { self.touched = {}; self.clearAll(); if (opts.onReset) { opts.onReset(); } }, 0);
    });
  }

  FormController.prototype.fieldOf = function (name) {
    var el = this.form.elements[name];
    var first = el && el.length && !el.tagName ? el[0] : el;
    return { el: el, first: first, wrap: first ? first.closest('.field') : null };
  };
  FormController.prototype.value = function (name) {
    var el = this.form.elements[name];
    if (!el) { return ''; }
    if (el.length && !el.tagName) { var c = Array.prototype.filter.call(el, function (r) { return r.checked; })[0]; return c ? c.value : ''; }
    return el.value;
  };
  FormController.prototype.values = function () {
    var out = {}, self = this;
    Array.prototype.forEach.call(this.form.elements, function (el) {
      if (!el.name || out.hasOwnProperty(el.name) || el.type === 'submit' || el.type === 'button' || el.type === 'reset') { return; }
      out[el.name] = el.type === 'checkbox' ? el.checked : self.value(el.name);
    });
    return out;
  };
  FormController.prototype.check = function (name) {
    var f = this.fieldOf(name);
    if (!f.wrap) { return ''; }
    var msg = this.rules[name](this.value(name), f.first, this.form);
    var errEl = $('.field-error', f.wrap);
    f.wrap.classList.toggle('has-error', !!msg);
    f.wrap.classList.toggle('is-valid', !msg && !!this.value(name));
    if (errEl) { errEl.textContent = msg; }
    var nodes = f.el.length && !f.el.tagName ? Array.prototype.slice.call(f.el) : [f.el];
    nodes.forEach(function (n) { if (msg) { n.setAttribute('aria-invalid', 'true'); } else { n.removeAttribute('aria-invalid'); } });
    return msg;
  };
  FormController.prototype.checkAll = function () {
    var self = this, bad = [];
    Object.keys(this.rules).forEach(function (name) {
      self.touched[name] = true;
      var msg = self.check(name);
      if (msg) { bad.push({ name: name, msg: msg, label: self.label(name) }); }
    });
    return bad;
  };
  FormController.prototype.label = function (name) {
    var f = this.fieldOf(name);
    var l = f.wrap && ($('label', f.wrap) || $('legend', f.wrap));
    return l ? l.textContent.replace('*', '').replace('required', '').trim() : name;
  };
  FormController.prototype.showSummary = function (bad) {
    var self = this;
    if (!this.summary) { return; }
    this.summary.innerHTML = '<h2 id="' + this.form.id + '-sum-title">Please fix ' + bad.length + (bad.length === 1 ? ' thing' : ' things') + ' before sending</h2><ul>' +
      bad.map(function (b) { return '<li><a href="#" data-focus="' + b.name + '">' + AH.escape(b.label) + ': ' + AH.escape(b.msg) + '</a></li>'; }).join('') + '</ul>';
    this.summary.classList.add('is-visible');
    this.summary.setAttribute('role', 'alert');
    this.summary.tabIndex = -1;
    this.summary.focus();
    $$('[data-focus]', this.summary).forEach(function (a) {
      a.addEventListener('click', function (e) { e.preventDefault(); var f = self.fieldOf(a.dataset.focus); if (f.first) { f.first.focus(); } });
    });
  };
  FormController.prototype.hideSummary = function () { if (this.summary) { this.summary.classList.remove('is-visible'); this.summary.innerHTML = ''; } };
  FormController.prototype.clearAll = function () {
    $$('.field', this.form).forEach(function (w) { w.classList.remove('has-error', 'is-valid'); var e = $('.field-error', w); if (e) { e.textContent = ''; } });
    $$('[aria-invalid]', this.form).forEach(function (n) { n.removeAttribute('aria-invalid'); });
    this.hideSummary();
  };

  /* ---- AJAX submit (real endpoint when configured, simulated otherwise) --- */
  function ajaxSubmit(payload) {
    var url = AH.config.formEndpoint;
    if (url && window.fetch) {
      return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(payload) })
        .then(function (r) { if (!r.ok) { throw new Error('Server responded ' + r.status); } return r.json().catch(function () { return {}; }); });
    }
    return new Promise(function (resolve) { window.setTimeout(function () { resolve({ simulated: true }); }, 900); });
  }
  function setBusy(btn, busy, idle) {
    btn.disabled = busy;
    btn.innerHTML = busy ? '<span class="spinner" aria-hidden="true"></span> Sending...' : idle;
  }

  /* ==========================================================================
     ENQUIRY
     ========================================================================== */
  var enquiry = $('#enquiry-form');
  if (enquiry) {
    var form = enquiry;
    var sel = $('#product-interest');
    var qtyEl = $('#quantity');
    var dateEl = $('#needed-by');

    /* Product select, built from the shared data */
    sel.innerHTML = '<option value="">Select a product (optional)</option>' +
      AH.categories.map(function (c) {
        return '<optgroup label="' + AH.escape(c.label) + '">' + AH.products.filter(function (p) { return p.category === c.id; }).map(function (p) {
          return '<option value="' + p.id + '">' + AH.escape(p.name) + ' (' + AH.formatRand(p.price) + ')</option>';
        }).join('') + '</optgroup>';
      }).join('') + '<option value="wholesale">Wholesale supply (daily deliveries)</option><option value="other">Something else</option>';

    /* Pre-select from ?product= */
    var qp = new URLSearchParams(window.location.search).get('product');
    if (qp && AH.getProduct(qp)) { sel.value = qp; }

    /* Earliest date: today + lead time, skipping closed days */
    function earliest() {
      var n = AH.saNow();
      var type = form.elements['enquiry_type'].value;
      var lead = type === 'custom-order' ? 2 : 1;
      var ids = AH.basket.all().map(function (i) { return AH.getProduct(i.id); });
      if (sel.value && AH.getProduct(sel.value)) { ids.push(AH.getProduct(sel.value)); }
      ids.forEach(function (p) { if (p.leadHours >= 48) { lead = 2; } });
      return AH.nextOpenDay(AH.addDays(n.iso, lead));
    }
    function setDateMin() {
      var min = earliest();
      dateEl.min = min;
      $('#date-hint').textContent = 'Earliest collection: ' + AH.formatDate(min) + '. We are closed on Sundays and public holidays.';
    }
    ['change'].forEach(function (ev) { form.elements['enquiry_type'].addEventListener(ev, setDateMin); sel.addEventListener(ev, setDateMin); });
    document.addEventListener('basket:change', setDateMin);
    setDateMin();

    /* Message counter */
    var msgEl = $('#message');
    var counter = $('#message-count');
    function count() { var l = msgEl.value.length; counter.textContent = l + ' / 800'; counter.classList.toggle('is-near', l > 720); }
    msgEl.addEventListener('input', count); count();

    /* Basket panel */
    var quote = $('#quote-body');
    function renderQuote() {
      var items = AH.basket.all();
      if (!items.length) {
        quote.innerHTML = '<p>Your enquiry list is empty. Pick products on the <a href="products.html">products page</a> to include them in your quote, or just describe what you need.</p>';
        return;
      }
      var total = 0;
      var rows = items.map(function (i) {
        var p = AH.getProduct(i.id); var line = p.price * i.qty; total += line;
        return '<li><span><strong>' + AH.escape(p.name) + '</strong><br><span class="hint">' + AH.formatRand(p.price) + ' ' + AH.escape(p.unit) + '</span></span>' +
          '<span class="qty"><button type="button" data-dec="' + p.id + '" aria-label="One fewer ' + AH.escape(p.name) + '">&minus;</button><output aria-live="polite">' + i.qty + '</output><button type="button" data-inc="' + p.id + '" aria-label="One more ' + AH.escape(p.name) + '">+</button></span>' +
          '<span class="hint">Line total ' + AH.formatRand(line) + '</span><button type="button" class="pill-link" data-remove="' + p.id + '">Remove</button></li>';
      }).join('');
      quote.innerHTML = '<ul class="quote-list">' + rows + '</ul><p class="quote-total"><span>Estimated total</span><span>' + AH.formatRand(total) + '</span></p><p class="hint">Prices include VAT. Final price is confirmed when we reply.</p>' +
        '<p style="margin-top:.75rem"><button type="button" class="pill-link" id="clear-basket">Clear list</button></p>';
    }
    quote.addEventListener('click', function (e) {
      var t = e.target;
      var inc = t.closest('[data-inc]'), dec = t.closest('[data-dec]'), rem = t.closest('[data-remove]');
      function qtyOf(id) { return AH.basket.all().filter(function (i) { return i.id === id; })[0].qty; }
      if (inc) { AH.basket.set(inc.dataset.inc, qtyOf(inc.dataset.inc) + 1); }
      if (dec) { AH.basket.set(dec.dataset.dec, qtyOf(dec.dataset.dec) - 1); }
      if (rem) { AH.basket.remove(rem.dataset.remove); }
      if (t.id === 'clear-basket') { AH.basket.clear(); }
    });
    document.addEventListener('basket:change', renderQuote);
    renderQuote();

    /* Rules */
    var rules = {
      name: V.name,
      email: V.email,
      phone: function (v, el, f) {
        var m = f.elements['contact_method'];
        var pref = Array.prototype.filter.call(m, function (r) { return r.checked; })[0];
        if (pref && (pref.value === 'phone' || pref.value === 'whatsapp')) { return V.phoneRequired(v); }
        return V.phoneOptional(v);
      },
      enquiry_type: V.select('Choose what your enquiry is about.'),
      quantity: function (v) {
        if (!v.trim()) { return ''; }
        var n = Number(v);
        if (!/^\d+$/.test(v.trim()) || n < 1 || n > 500) { return 'Enter a whole number between 1 and 500.'; }
        return '';
      },
      needed_by: function (v) {
        if (!v) { return ''; }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) { return 'Enter a valid date.'; }
        var n = AH.saNow();
        if (v < n.iso) { return 'That date has already passed. Choose today or later.'; }
        if (AH.isClosedDay(v, AH.weekdayOf(v))) { return 'We are closed on that day. Pick a Monday to Saturday that is not a public holiday.'; }
        if (v < earliest()) { return 'We need more notice for this order. The earliest date is ' + AH.formatDate(earliest()) + '.'; }
        if (v > AH.addDays(n.iso, 365)) { return 'Choose a date within the next year.'; }
        return '';
      },
      message: V.text(15, 800, 'a message'),
      contact_method: V.select('Choose how we should reply.'),
      consent: V.checked('Tick the box so we can store your details to reply to you.')
    };

    var ctrl = new FormController(form, rules, {
      onValid: function (v, c) {
        if (v.website) { return; } /* honeypot: bots fill it in */
        var btn = $('button[type="submit"]', form);
        var idle = btn.innerHTML;
        setBusy(btn, true);
        var items = AH.basket.all().map(function (i) { var p = AH.getProduct(i.id); return { id: i.id, name: p.name, qty: i.qty, unit_price: p.price }; });
        ajaxSubmit({ form: 'enquiry', fields: v, basket: items, sent: new Date().toISOString() }).then(function () {
          setBusy(btn, false, idle);
          showResponse(v);
        }).catch(function () {
          setBusy(btn, false, idle);
          c.summary.innerHTML = '<h2>We could not send your enquiry</h2><p>Check your connection and try again, or email <a href="mailto:' + AH.config.email + '">' + AH.config.email + '</a>.</p>';
          c.summary.classList.add('is-visible'); c.summary.focus();
        });
      },
      onReset: function () { $('#enquiry-response').classList.remove('is-visible'); count(); setDateMin(); }
    });

    function buildLines(v) {
      var lines = AH.basket.all().map(function (i) { var p = AH.getProduct(i.id); return { id: p.id, name: p.name, qty: i.qty, price: p.price }; });
      var picked = AH.getProduct(v.product_interest);
      var already = picked && lines.some(function (l) { return l.id === picked.id; });
      if (picked && !already) { lines.push({ id: picked.id, name: picked.name, qty: Number(v.quantity) || 1, price: picked.price }); }
      return lines;
    }

    function showResponse(v) {
      var box = $('#enquiry-response');
      var lines = buildLines(v);
      var total = lines.reduce(function (s, l) { return s + l.qty * l.price; }, 0);
      var first = (v.name.trim().split(/\s+/)[0]) || 'there';
      var date = v.needed_by ? AH.formatDate(v.needed_by) : AH.formatDate(earliest());
      var reply = { email: 'by email', phone: 'by phone', whatsapp: 'on WhatsApp' }[v.contact_method];
      var typeLabel = { wholesale: 'Wholesale', 'custom-order': 'Custom order', general: 'General question', feedback: 'Feedback' }[v.enquiry_type] || 'Enquiry';
      var html = '<h2>Thank you, ' + AH.escape(first) + '. We have your enquiry.</h2>';

      if (lines.length) {
        var discount = 0, note = '';
        if (v.enquiry_type === 'wholesale' && total >= 1500) { discount = total >= 4000 ? 0.15 : 0.1; note = 'Wholesale volume discount applied: ' + (discount * 100) + '%.'; }
        html += '<p>Here is your estimate:</p><table><thead><tr><th>Item</th><th>Qty</th><th>Price</th></tr></thead><tbody>' +
          lines.map(function (l) { return '<tr><td>' + AH.escape(l.name) + '</td><td>' + l.qty + '</td><td>' + AH.formatRand(l.qty * l.price) + '</td></tr>'; }).join('') +
          (discount ? '<tr><td colspan="2">Volume discount (' + (discount * 100) + '%)</td><td>&minus;' + AH.formatRand(total * discount) + '</td></tr>' : '') +
          '<tr><th colspan="2">Estimated total</th><th>' + AH.formatRand(total * (1 - discount)) + '</th></tr></tbody></table>' + (note ? '<p><strong>' + note + '</strong></p>' : '');
      } else if (v.enquiry_type === 'wholesale' || v.product_interest === 'wholesale') {
        html += '<p><strong>Wholesale pricing:</strong> 10% off weekly orders over R1&nbsp;500 and 15% off orders over R4&nbsp;000, with daily delivery around Pretoria. We will send a tailored price list.</p>';
      } else {
        html += '<p>We will confirm pricing once we know exactly what you need. Our breads start at R38, pastries at R22 and celebration cakes at R300.</p>';
      }

      var avail;
      if (v.enquiry_type === 'custom-order' || lines.some(function (l) { return /cake/i.test(l.name); })) {
        avail = 'Celebration cakes need 48 hours&rsquo; notice. The earliest we can have yours ready is <strong>' + date + '</strong>.';
      } else {
        avail = 'We can have this ready for collection from <strong>' + date + '</strong>.';
      }
      html += '<dl><dt>Type</dt><dd>' + typeLabel + '</dd><dt>Availability</dt><dd>' + avail + '</dd><dt>Reply</dt><dd>We will reply ' + reply + ' within one business day (' + AH.escape(AH.openStatus().open ? 'we are open now, so it may be sooner' : AH.openStatus().detail.toLowerCase()) + ').</dd></dl>';
      html += '<div class="btn-row"><a class="btn" href="products.html">Keep browsing</a><button type="button" class="btn btn--ghost" id="new-enquiry" style="color:var(--enamel-deep);border-color:var(--enamel-deep)">Start another enquiry</button></div>';
      box.innerHTML = html;
      box.classList.add('is-visible');
      box.tabIndex = -1;
      box.focus();
      box.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
      $('#new-enquiry').addEventListener('click', function () { form.reset(); AH.basket.clear(); box.classList.remove('is-visible'); form.elements['name'].focus(); });
      AH.toast('Enquiry sent. We will be in touch soon.');
    }
  }

  /* ==========================================================================
     CONTACT  (compiles an email addressed to the recipient in AH.config)
     ========================================================================== */
  var contact = $('#contact-form');
  if (contact) {
    var cform = contact;
    var cmsg = $('#c-message');
    var ccount = $('#c-message-count');
    function ccounter() { var l = cmsg.value.length; ccount.textContent = l + ' / 1000'; ccount.classList.toggle('is-near', l > 900); }
    cmsg.addEventListener('input', ccounter); ccounter();

    var typeLabels = { question: 'Question about products', order: 'Order or collection', event: 'Event or catering', feedback: 'Feedback or compliment', complaint: 'Complaint', press: 'Press or partnerships', job: 'Work with us', other: 'Something else' };

    var cRules = {
      name: V.name,
      email: V.email,
      phone: V.phoneOptional,
      message_type: V.select('Choose the type of message.'),
      subject: V.text(4, 100, 'a subject'),
      message: V.text(20, 1000, 'your message'),
      consent: V.checked('Tick the box so we can reply to you.')
    };

    var cctrl = new FormController(cform, cRules, {
      onValid: function (v) {
        if (v.website) { return; }
        var btn = $('button[type="submit"]', cform);
        var idle = btn.innerHTML;
        setBusy(btn, true);
        var email = compileEmail(v);
        ajaxSubmit({ form: 'contact', fields: v, email: email, sent: new Date().toISOString() }).then(function (res) {
          setBusy(btn, false, idle);
          showEmail(v, email, res);
        }).catch(function () {
          setBusy(btn, false, idle);
          showEmail(v, email, { failed: true });
        });
      },
      onReset: function () { $('#contact-response').classList.remove('is-visible'); ccounter(); }
    });

    function compileEmail(v) {
      var subject = '[' + (typeLabels[v.message_type] || 'Website message') + '] ' + v.subject.trim();
      var body = 'Hello Artisan’s Hearth Bakery,\n\n' + v.message.trim() + '\n\n' +
        '-----------------------------\n' +
        'Name: ' + v.name.trim() + '\n' +
        'Email: ' + v.email.trim() + '\n' +
        'Phone: ' + (v.phone.trim() || 'not provided') + '\n' +
        'Message type: ' + (typeLabels[v.message_type] || v.message_type) + '\n' +
        'Sent from: ' + window.location.hostname + '\n';
      return {
        to: AH.config.email, subject: subject, body: body,
        href: 'mailto:' + AH.config.email + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body)
      };
    }

    function showEmail(v, email, res) {
      var box = $('#contact-response');
      var first = v.name.trim().split(/\s+/)[0];
      box.innerHTML = '<h2>' + AH.escape(first) + ', your message is ready to send</h2>' +
        '<p>' + (res && res.failed ? 'We could not send it automatically, so please send it from your own email app.' : 'We have prepared the email below. Press <strong>Open in my email app</strong> to send it to <strong>' + AH.escape(email.to) + '</strong>.') + '</p>' +
        '<p><strong>Subject:</strong> ' + AH.escape(email.subject) + '</p><div class="email-preview" tabindex="0" role="region" aria-label="Email preview">' + AH.escape(email.body) + '</div>' +
        '<div class="btn-row"><a class="btn" href="' + email.href + '" id="send-mail">Open in my email app</a><button type="button" class="btn btn--ghost" id="copy-mail" style="color:var(--enamel-deep);border-color:var(--enamel-deep)">Copy message</button></div>' +
        '<p class="hint" style="margin-top:.75rem">We reply within one business day. ' + AH.escape(AH.openStatus().detail) + '.</p>';
      box.classList.add('is-visible');
      box.tabIndex = -1; box.focus();
      box.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
      $('#copy-mail').addEventListener('click', function () {
        var txt = 'To: ' + email.to + '\nSubject: ' + email.subject + '\n\n' + email.body;
        if (navigator.clipboard) { navigator.clipboard.writeText(txt).then(function () { AH.toast('Message copied'); }, function () { AH.toast('Copy failed'); }); }
      });
    }
  }
})();
