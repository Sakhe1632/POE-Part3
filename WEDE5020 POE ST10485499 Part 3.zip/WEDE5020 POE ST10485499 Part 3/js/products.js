/* ==========================================================================
   Products page: dynamic listing, live search, category filter, sorting,
   details modal (<dialog>) and "add to enquiry" basket.
   ========================================================================== */
(function () {
  'use strict';
  var AH = window.AH;
  var $ = AH.$;

  var grid = $('#product-grid');
  if (!grid) { return; }

  var els = {
    search: $('#product-search'),
    sort: $('#product-sort'),
    chips: $('#category-chips'),
    count: $('#results-count'),
    empty: $('#product-empty'),
    reset: $('#reset-filters'),
    live: $('#results-live'),
    dialog: $('#product-dialog'),
    dialogBody: $('#product-dialog-body')
  };

  var state = { q: '', category: 'all', sort: 'featured' };
  var lastTrigger = null;

  /* ---- Helpers -------------------------------------------------------- */
  function highlight(text, q) {
    var safe = AH.escape(text);
    if (!q) { return safe; }
    var terms = q.split(/\s+/).filter(Boolean).map(function (t) { return AH.escape(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); });
    if (!terms.length) { return safe; }
    return safe.replace(new RegExp('(' + terms.join('|') + ')', 'gi'), '<mark>$1</mark>');
  }

  function matches(p, q) {
    if (!q) { return true; }
    var hay = (p.name + ' ' + p.short + ' ' + p.long + ' ' + p.ingredients + ' ' + p.tags.join(' ') + ' ' + p.category).toLowerCase();
    return q.toLowerCase().split(/\s+/).filter(Boolean).every(function (t) { return hay.indexOf(t) !== -1; });
  }

  function sorted(list) {
    var arr = list.slice();
    var by = {
      'featured': function (a, b) { return (b.featured ? 1 : 0) - (a.featured ? 1 : 0); },
      'price-asc': function (a, b) { return a.price - b.price; },
      'price-desc': function (a, b) { return b.price - a.price; },
      'name': function (a, b) { return a.name.localeCompare(b.name); }
    };
    return arr.map(function (p, i) { return { p: p, i: i }; })
      .sort(function (a, b) { return by[state.sort](a.p, b.p) || a.i - b.i; })
      .map(function (x) { return x.p; });
  }

  function leadLabel(p) { return p.leadHours >= 48 ? 'Order 2 days ahead' : 'Order 1 day ahead'; }

  function cardHtml(p) {
    var im = AH.img(p.img);
    var inBasket = AH.basket.has(p.id);
    return '<li><article class="card is-entering" data-id="' + p.id + '">' +
      '<div class="card__media"><img src="' + im.src + '" srcset="' + im.srcset + '" sizes="(max-width: 600px) 92vw, 280px" width="' + im.w + '" height="' + im.h + '" alt="' + AH.escape(p.alt) + '" loading="lazy" decoding="async"></div>' +
      '<div class="card__body">' +
      '<ul class="tags" aria-label="Product labels">' + p.tags.map(function (t) { return '<li class="tag">' + AH.escape(t) + '</li>'; }).join('') + '<li class="tag tag--lead">' + leadLabel(p) + '</li></ul>' +
      '<h3>' + highlight(p.name, state.q) + '</h3>' +
      '<p class="card__desc">' + highlight(p.short, state.q) + '</p>' +
      '<div class="card__foot"><p class="price">' + AH.formatRand(p.price) + '<small>' + AH.escape(p.unit) + '</small></p>' +
      '<button type="button" class="pill-link" data-details="' + p.id + '" aria-label="View details for ' + AH.escape(p.name) + '">Details</button></div>' +
      '<button type="button" class="btn btn--small ' + (inBasket ? 'btn--ghost' : '') + '" data-add="' + p.id + '">' + (inBasket ? 'Added. Add another' : 'Add to enquiry') + '</button>' +
      '</div></article></li>';
  }

  /* ---- Render ---------------------------------------------------------- */
  function render() {
    var list = sorted(AH.products.filter(function (p) {
      return (state.category === 'all' || p.category === state.category) && matches(p, state.q);
    }));

    grid.innerHTML = list.map(cardHtml).join('');
    var n = list.length;
    var msg = n === 0 ? 'No products found' : 'Showing ' + n + (n === 1 ? ' product' : ' products');
    els.count.textContent = msg;
    els.live.textContent = msg + (state.q ? ' for ' + state.q : '');
    els.empty.hidden = n !== 0;
    grid.hidden = n === 0;
    syncUrl();
  }

  function syncUrl() {
    if (!window.history || !window.history.replaceState) { return; }
    var params = new URLSearchParams();
    if (state.q) { params.set('q', state.q); }
    if (state.category !== 'all') { params.set('category', state.category); }
    if (state.sort !== 'featured') { params.set('sort', state.sort); }
    var qs = params.toString();
    try { window.history.replaceState(null, '', window.location.pathname + (qs ? '?' + qs : '')); } catch (e) { /* file:// */ }
  }

  function setCategory(id) {
    state.category = id;
    AH.$$('button', els.chips).forEach(function (b) { b.setAttribute('aria-pressed', String(b.dataset.category === id)); });
  }

  /* ---- Chips ----------------------------------------------------------- */
  var chipHtml = '<button type="button" class="chip" data-category="all" aria-pressed="true">All products</button>' +
    AH.categories.map(function (c) { return '<button type="button" class="chip" data-category="' + c.id + '" aria-pressed="false">' + AH.escape(c.label) + '</button>'; }).join('');
  els.chips.innerHTML = chipHtml;
  els.chips.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-category]');
    if (!b) { return; }
    setCategory(b.dataset.category);
    render();
  });

  /* ---- Search (debounced) ------------------------------------------------ */
  var timer;
  els.search.addEventListener('input', function () {
    window.clearTimeout(timer);
    timer = window.setTimeout(function () { state.q = els.search.value.trim(); render(); }, 150);
  });
  els.search.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && els.search.value) { els.search.value = ''; state.q = ''; render(); }
  });
  els.sort.addEventListener('change', function () { state.sort = els.sort.value; render(); });
  els.reset.addEventListener('click', function () {
    els.search.value = ''; els.sort.value = 'featured';
    state.q = ''; state.sort = 'featured'; setCategory('all'); render(); els.search.focus();
  });

  /* ---- Grid actions: add + details -------------------------------------- */
  grid.addEventListener('click', function (e) {
    var add = e.target.closest('[data-add]');
    var det = e.target.closest('[data-details]');
    if (add) {
      var p = AH.getProduct(add.dataset.add);
      AH.basket.add(p.id, 1);
      add.textContent = 'Added. Add another';
      add.classList.add('btn--ghost');
      AH.toast(p.name + ' added to your enquiry (' + AH.basket.count() + ')');
    }
    if (det) { lastTrigger = det; openDialog(det.dataset.details); }
  });

  /* ---- Modal ------------------------------------------------------------- */
  function openDialog(id) {
    var p = AH.getProduct(id);
    var im = AH.img(p.img);
    els.dialogBody.innerHTML =
      '<div class="split split--even">' +
      '<img src="' + im.full + '" width="' + im.w + '" height="' + im.h + '" alt="' + AH.escape(p.alt) + '" style="border-radius:10px;width:100%">' +
      '<div><h2 id="dialog-title">' + AH.escape(p.name) + '</h2>' +
      '<p class="price" style="margin:.4rem 0">' + AH.formatRand(p.price) + '<small>' + AH.escape(p.unit) + '</small></p>' +
      '<p>' + AH.escape(p.long) + '</p>' +
      '<div class="accordion" data-accordion data-single style="margin-top:1rem">' +
      accordionItem('d-ing', 'Ingredients', '<p>' + AH.escape(p.ingredients) + '</p>', true) +
      accordionItem('d-all', 'Allergens', '<p><strong>Contains:</strong> ' + AH.escape(p.allergens) + '. Baked in a kitchen that also handles nuts and sesame.</p>') +
      accordionItem('d-ord', 'Ordering and collection', '<p>' + leadLabel(p) + '. Baked on ' + dayList(p.days) + '. Collect in store or ask about delivery.</p>') +
      '</div>' +
      '<p style="margin-top:1.25rem"><button type="button" class="btn" data-dialog-add="' + p.id + '">Add to enquiry</button></p></div></div>';
    AH.initAccordions(els.dialogBody);
    if (els.dialog.showModal) { els.dialog.showModal(); } else { els.dialog.setAttribute('open', ''); }
    document.body.style.overflow = 'hidden';
  }
  function accordionItem(id, title, content, open) {
    return '<div class="accordion__item"><h3 class="accordion__heading"><button type="button" class="accordion__trigger" id="' + id + '-t" aria-expanded="' + (open ? 'true' : 'false') + '" aria-controls="' + id + '-p">' + title + '<span class="accordion__icon" aria-hidden="true"></span></button></h3>' +
      '<div class="accordion__panel" id="' + id + '-p" role="region" aria-labelledby="' + id + '-t"><div class="accordion__inner">' + content + '</div></div></div>';
  }
  function dayList(days) {
    var names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    if (days.length === 6 && days.indexOf(0) === -1) { return 'Monday to Saturday'; }
    return days.map(function (d) { return names[d]; }).join(', ');
  }
  function closeDialog() { if (els.dialog.close) { els.dialog.close(); } else { els.dialog.removeAttribute('open'); } }
  els.dialog.addEventListener('close', function () { document.body.style.overflow = ''; if (lastTrigger) { lastTrigger.focus(); } });
  els.dialog.addEventListener('click', function (e) {
    if (e.target === els.dialog) { closeDialog(); }
    var add = e.target.closest('[data-dialog-add]');
    if (add) { var p = AH.getProduct(add.dataset.dialogAdd); AH.basket.add(p.id, 1); AH.toast(p.name + ' added to your enquiry'); closeDialog(); render(); }
    if (e.target.closest('[data-dialog-close]')) { closeDialog(); }
  });

  /* ---- Init from URL ------------------------------------------------------ */
  (function init() {
    var params = new URLSearchParams(window.location.search);
    var q = params.get('q') || '';
    var cat = params.get('category');
    var sort = params.get('sort');
    if (q) { state.q = q.slice(0, 60); els.search.value = state.q; }
    if (cat && AH.categories.some(function (c) { return c.id === cat; })) { setCategory(cat); }
    if (sort && ['featured', 'price-asc', 'price-desc', 'name'].indexOf(sort) !== -1) { state.sort = sort; els.sort.value = sort; }
    render();
  })();
})();
