/* ==========================================================================
   Gallery: filterable grid + accessible lightbox
   (keyboard arrows / Escape, swipe on touch, focus trap, preloading).
   ========================================================================== */
(function () {
  'use strict';
  var AH = window.AH;
  var $ = AH.$;
  var grid = $('#gallery-grid');
  if (!grid) { return; }

  var lb = $('#lightbox');
  var imgEl = $('#lightbox-img');
  var titleEl = $('#lightbox-title');
  var capEl = $('#lightbox-caption');
  var countEl = $('#lightbox-count');
  var chips = $('#gallery-chips');
  var visible = AH.gallery.slice();
  var current = 0;
  var opener = null;

  function item(g, i) {
    var im = AH.img(g.img);
    return '<figure class="gallery__item"><button type="button" class="gallery__btn" data-index="' + i + '" aria-label="Open larger view: ' + AH.escape(g.title) + '">' +
      '<img src="' + im.src + '" srcset="' + im.srcset + '" sizes="(max-width: 600px) 92vw, 360px" width="' + im.w + '" height="' + im.h + '" alt="' + AH.escape(g.alt) + '" loading="' + (i < 3 ? 'eager' : 'lazy') + '" decoding="async">' +
      '<span class="gallery__label">' + AH.escape(g.title) + '</span></button></figure>';
  }
  function render() { grid.innerHTML = visible.map(item).join(''); }

  /* Filter chips */
  chips.innerHTML = '<button type="button" class="chip" data-cat="all" aria-pressed="true">All photos</button>' +
    AH.categories.map(function (c) { return '<button type="button" class="chip" data-cat="' + c.id + '" aria-pressed="false">' + AH.escape(c.label) + '</button>'; }).join('');
  chips.addEventListener('click', function (e) {
    var b = e.target.closest('[data-cat]');
    if (!b) { return; }
    AH.$$('button', chips).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
    visible = b.dataset.cat === 'all' ? AH.gallery.slice() : AH.gallery.filter(function (g) { return g.category === b.dataset.cat; });
    render();
    $('#gallery-live').textContent = 'Showing ' + visible.length + ' photos';
  });

  function show(i) {
    current = (i + visible.length) % visible.length;
    var g = visible[current];
    var im = AH.img(g.img);
    imgEl.src = im.full;
    imgEl.alt = g.alt;
    imgEl.width = im.w; imgEl.height = im.h;
    titleEl.textContent = g.title;
    capEl.textContent = g.caption;
    countEl.textContent = (current + 1) + ' of ' + visible.length;
    [1, -1].forEach(function (d) { var n = visible[(current + d + visible.length) % visible.length]; new Image().src = AH.img(n.img).full; });
  }
  function open(i, trigger) {
    opener = trigger;
    show(i);
    lb.classList.add('is-open');
    lb.removeAttribute('aria-hidden');
    document.body.style.overflow = 'hidden';
    $('.lightbox__close', lb).focus();
  }
  function close() {
    lb.classList.remove('is-open');
    lb.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (opener) { opener.focus(); }
  }

  grid.addEventListener('click', function (e) {
    var b = e.target.closest('.gallery__btn');
    if (b) { open(+b.dataset.index, b); }
  });
  $('.lightbox__close', lb).addEventListener('click', close);
  $('.lightbox__prev', lb).addEventListener('click', function () { show(current - 1); });
  $('.lightbox__next', lb).addEventListener('click', function () { show(current + 1); });
  lb.addEventListener('click', function (e) { if (e.target === lb || e.target.classList.contains('lightbox__stage')) { close(); } });

  document.addEventListener('keydown', function (e) {
    if (!lb.classList.contains('is-open')) { return; }
    if (e.key === 'Escape') { close(); }
    else if (e.key === 'ArrowRight') { show(current + 1); }
    else if (e.key === 'ArrowLeft') { show(current - 1); }
    else if (e.key === 'Tab') {
      var f = AH.$$('button', lb).filter(function (b) { return !b.hidden; });
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  /* Swipe */
  var x0 = null;
  var stage = $('.lightbox__stage', lb);
  stage.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
  stage.addEventListener('touchend', function (e) {
    if (x0 === null) { return; }
    var dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 50) { show(current + (dx < 0 ? 1 : -1)); }
    x0 = null;
  });

  render();
})();
