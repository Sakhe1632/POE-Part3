#!/usr/bin/env python3
"""
Static page generator for Artisan's Hearth Bakery (WEDE5020 POE Part 3).

Why it exists: every page shares the same <head>, header and footer. Generating
them from one template keeps titles, meta tags, navigation and structured data
consistent, and reads js/data.js so products, JSON-LD and the sitemap never
drift apart.

Usage (from the project root):
    SITE_URL=https://your-name.github.io/your-repo/ python3 tools/build.py
"""
import html
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SITE_URL = os.environ.get("SITE_URL", "https://artisans-hearth-bakery.netlify.app/").rstrip("/") + "/"
TODAY = os.environ.get("BUILD_DATE", "2026-11-02")
BRAND = "Artisan’s Hearth Bakery"

# ---- Load shared data from js/data.js (single source of truth) --------------
node = r"""
global.window = {};
require(process.argv[1]);
const AH = window.AH;
console.log(JSON.stringify({config: AH.config, products: AH.products, categories: AH.categories,
  gallery: AH.gallery, team: AH.team, hours: AH.hours, posts: AH.posts}));
"""
data = json.loads(subprocess.check_output(["node", "-e", node, str(ROOT / "js" / "data.js")]))
CFG, PRODUCTS = data["config"], data["products"]
PBY = {p["id"]: p for p in PRODUCTS}


def e(s):
    return html.escape(str(s), quote=True)


def rand(n):
    return "R" + f"{n:,.2f}".replace(",", " ")


def img_tag(key, alt, sizes, loading="lazy", cls="", extra=""):
    manifest = {
        p: sorted(int(f.stem.rsplit("-", 1)[1]) for f in (ROOT / "images").glob(p + "-*.webp"))
        for p in {pr["img"] for pr in PRODUCTS} | {g["img"] for g in data["gallery"]}
    }
    widths = manifest[key]
    big = widths[-1]
    # intrinsic size from the largest file
    from PIL import Image
    with Image.open(ROOT / "images" / f"{key}-{big}.webp") as im:
        w, h = im.size
    srcset = ", ".join(f"images/{key}-{wd}.webp {wd}w" for wd in widths)
    c = f' class="{cls}"' if cls else ""
    return (f'<img{c} src="images/{key}-{big}.webp" srcset="{srcset}" sizes="{sizes}" width="{w}" height="{h}" '
            f'alt="{e(alt)}" loading="{loading}" decoding="async"{extra}>')


# ---- Pages --------------------------------------------------------------------
NAV = [("index.html", "Home"), ("about.html", "About"), ("products.html", "Products"),
       ("gallery.html", "Gallery"), ("enquiry.html", "Enquiry"), ("contact.html", "Contact")]

OG_IMAGE = "images/artisans-hearth-bakery-social-share.jpg"


def head(page):
    url = SITE_URL + ("" if page["file"] == "index.html" else page["file"])
    robots = page.get("robots", "index, follow, max-image-preview:large")
    ld = "\n".join(f'<script type="application/ld+json">{json.dumps(b, ensure_ascii=False, separators=(",", ":"))}</script>'
                   for b in page.get("ld", []))
    return f"""<!DOCTYPE html>
<html lang="en-ZA">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(page["title"])}</title>
<meta name="description" content="{e(page["description"])}">
<meta name="keywords" content="{e(page["keywords"])}">
<meta name="author" content="{e(BRAND)}">
<meta name="robots" content="{robots}">
<meta name="theme-color" content="#17384d">
<meta name="referrer" content="strict-origin-when-cross-origin">
<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self' https://unpkg.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://unpkg.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https://tile.openstreetmap.org https://unpkg.com; connect-src 'self' https://formspree.io; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'">
<link rel="canonical" href="{url}">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{e(BRAND)}">
<meta property="og:locale" content="en_ZA">
<meta property="og:title" content="{e(page["title"])}">
<meta property="og:description" content="{e(page["description"])}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{SITE_URL}{OG_IMAGE}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Golden butter croissants dusted with flour on a dark slate board">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{e(page["title"])}">
<meta name="twitter:description" content="{e(page["description"])}">
<meta name="twitter:image" content="{SITE_URL}{OG_IMAGE}">
<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" href="css/style.css" as="style">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700;800&family=Young+Serif&display=swap">
<link rel="stylesheet" href="css/style.css">
{ld}
</head>
"""


def header(current):
    links = []
    for href, label in NAV:
        cur = ' aria-current="page"' if href == current else ""
        badge = ' <span class="badge" data-basket-count hidden>0</span>' if href == "enquiry.html" else ""
        links.append(f'<li><a href="{href}"{cur}>{label}{badge}</a></li>')
    return f"""<body>
<a class="skip-link" href="#main">Skip to main content</a>
<div class="status-bar">
  <div class="wrap">
    <p class="status" data-open-status role="status"><span class="status__dot" aria-hidden="true"></span><strong data-status-label>Checking hours</strong><span data-status-detail></span></p>
    <p>Call <a href="{CFG["phoneHref"]}">{CFG["phone"]}</a></p>
  </div>
</div>
<header class="site-header">
  <div class="wrap site-header__bar">
    <a class="brand" href="index.html" aria-label="Artisan&rsquo;s Hearth Bakery, home"><span class="brand__mark" aria-hidden="true">&#9832;&#xFE0E;</span>&nbsp;Artisan&rsquo;s Hearth</a>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav"><span class="nav-toggle__bars" aria-hidden="true"></span><span class="sr-only">Open menu</span></button>
    <nav class="site-nav" id="site-nav" aria-label="Main">
      <ul>
        {chr(10).join("        " + l for l in links).strip()}
      </ul>
    </nav>
  </div>
</header>
"""


def footer(scripts):
    nav = "".join(f'<li><a href="{h}">{l}</a></li>' for h, l in NAV)
    return f"""<footer class="site-footer">
  <div class="wrap">
    <div class="footer-grid">
      <div>
        <h2>Artisan&rsquo;s Hearth Bakery</h2>
        <p>Handcrafted sourdough, croissants and celebration cakes baked fresh in Pretoria with love, tradition and the finest local ingredients.</p>
        <div class="share" data-share style="margin-top:1rem;color:#fff" aria-label="Share this page">
          <span class="sr-only">Share this page:</span>
          <a data-share-whatsapp href="https://wa.me/" target="_blank" rel="noopener noreferrer">WhatsApp</a>
          <a data-share-facebook href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer">Facebook</a>
          <a data-share-x href="https://twitter.com/" target="_blank" rel="noopener noreferrer">X</a>
          <button type="button" data-share-copy>Copy link</button>
        </div>
      </div>
      <div>
        <h2>Explore</h2>
        <ul>{nav}</ul>
      </div>
      <div>
        <h2>Visit us</h2>
        <address>
          <ul>
            <li>123 Main Street<br>Pretoria, Gauteng, 0001</li>
            <li><a href="{CFG["phoneHref"]}">{CFG["phone"]}</a></li>
            <li><a href="mailto:{CFG["email"]}">{CFG["email"]}</a></li>
          </ul>
        </address>
      </div>
      <div>
        <h2>Hours</h2>
        <ul>
          <li>Mon&ndash;Fri: 7:00 am &ndash; 6:00 pm</li>
          <li>Saturday: 8:00 am &ndash; 4:00 pm</li>
          <li>Sunday and public holidays: closed</li>
          <li><a href="https://www.facebook.com/artisanshearthbakery" rel="noopener noreferrer" target="_blank">Facebook</a> &middot; <a href="https://www.instagram.com/artisanshearthbakery" rel="noopener noreferrer" target="_blank">Instagram</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; <span data-year>2026</span> Artisan&rsquo;s Hearth Bakery. All rights reserved.</p>
      <p>Student project for WEDE5020, The Independent Institute of Education. Not a real business.</p>
    </div>
  </div>
</footer>
<div id="toast" role="status" aria-live="polite"></div>
<button id="back-to-top" type="button" aria-label="Back to top">&uarr;</button>
<script src="js/data.js"></script>
<script src="js/main.js"></script>
{scripts}
</body>
</html>
"""


def page_hero(title, lead, crumbs):
    bc = "".join(f'<li><a href="{h}">{l}</a></li>' for h, l in crumbs[:-1]) + f'<li aria-current="page">{crumbs[-1][1]}</li>'
    return f"""<section class="page-hero">
  <div class="wrap">
    <nav aria-label="Breadcrumb"><ol class="breadcrumb">{bc}</ol></nav>
    <h1>{title}</h1>
    <p>{lead}</p>
  </div>
</section>
"""


def breadcrumb_ld(name, file):
    items = [{"@type": "ListItem", "position": 1, "name": "Home", "item": SITE_URL}]
    if file != "index.html":
        items.append({"@type": "ListItem", "position": 2, "name": name, "item": SITE_URL + file})
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": items}


SAME_AS = ["https://www.facebook.com/artisanshearthbakery", "https://www.instagram.com/artisanshearthbakery"]
BAKERY_LD = {
    "@context": "https://schema.org", "@type": "Bakery", "@id": SITE_URL + "#bakery",
    "name": "Artisan's Hearth Bakery", "url": SITE_URL, "image": SITE_URL + OG_IMAGE,
    "description": "Handcrafted sourdough, croissants and celebration cakes baked fresh daily in Pretoria.",
    "telephone": "+27123456789", "email": CFG["email"], "priceRange": "R22 - R350",
    "servesCuisine": "Bakery", "currenciesAccepted": "ZAR",
    "address": {"@type": "PostalAddress", "streetAddress": "123 Main Street", "addressLocality": "Pretoria",
                "addressRegion": "Gauteng", "postalCode": "0001", "addressCountry": "ZA"},
    "geo": {"@type": "GeoCoordinates", "latitude": CFG["lat"], "longitude": CFG["lng"]},
    "openingHoursSpecification": [
        {"@type": "OpeningHoursSpecification", "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], "opens": "07:00", "closes": "18:00"},
        {"@type": "OpeningHoursSpecification", "dayOfWeek": "Saturday", "opens": "08:00", "closes": "16:00"}],
    "areaServed": {"@type": "City", "name": "Pretoria"}, "sameAs": SAME_AS,
}


def product_card(p, loading="lazy"):
    tags = "".join(f'<li class="tag">{e(t)}</li>' for t in p["tags"][:2])
    return f"""<li><article class="card">
  <div class="card__media">{img_tag(p["img"], p["alt"], "(max-width: 600px) 92vw, 280px", loading)}</div>
  <div class="card__body">
    <ul class="tags" aria-label="Product labels">{tags}</ul>
    <h3>{e(p["name"])}</h3>
    <p class="card__desc">{e(p["short"])}</p>
    <div class="card__foot"><p class="price">{rand(p["price"])}<small>{e(p["unit"])}</small></p>
    <a class="text-link" href="products.html?q={e(p["name"]).replace(" ", "%20")}">View details</a></div>
  </div>
</article></li>"""


PAGES = {}

# ---------------- HOME ------------------------------------------------------------
featured = [p for p in PRODUCTS if p["featured"]][:4]
home_body = f"""<main id="main">
<section class="hero" aria-labelledby="hero-title">
  {img_tag("butter-croissants-on-slate-flour-dusting", "Golden butter croissants dusted with flour on dark slate, fresh from the Artisan's Hearth oven", "100vw", "eager", "hero__img", ' fetchpriority="high"')}
  <div class="wrap hero__inner">
    <h1 id="hero-title" class="hero__fade">Fresh artisan bread baked in Pretoria every morning</h1>
    <p class="hero__fade">Slow-fermented sourdough, hand-laminated croissants and celebration cakes, made with local flour and a ten-year-old starter.</p>
    <div class="hero__actions hero__fade">
      <a class="btn" href="products.html">Browse our products</a>
      <a class="btn btn--ghost" href="enquiry.html">Order a celebration cake</a>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="story-title">
  <div class="wrap split">
    <div>
      <h2 id="story-title">Bread the slow way, since 2016</h2>
      <p class="lede" style="margin-block:1rem 1.25rem">Great bread is more than food. It is a connection to tradition, community and the simple pleasures of life.</p>
      <p>Every loaf at our Pretoria artisan bakery is shaped by hand, fermented for up to 24 hours and baked in a steam oven for a crackling crust. Come in early and taste the difference that patience makes.</p>
      <dl class="stats">
        <div><dt><span data-years-baking>10</span></dt><dd>years baking</dd></div>
        <div><dt>24h</dt><dd>sourdough ferment</dd></div>
        <div><dt>6</dt><dd>days a week</dd></div>
      </dl>
      <p style="margin-top:1.5rem"><a class="btn btn--ghost" href="about.html">Meet the bakers</a></p>
    </div>
    <aside class="oven" aria-labelledby="oven-day">
      <h2 id="oven-day">On the oven today</h2>
      <ul id="oven-list"><li class="oven__rest">Loading today&rsquo;s bake&hellip;</li></ul>
      <p class="hint" style="margin-top:.75rem">Order a day ahead to guarantee yours.</p>
    </aside>
  </div>
</section>

<section class="section section--dark" aria-labelledby="why-title">
  <div class="wrap">
    <div class="section-head"><h2 id="why-title">Why Pretoria chooses Artisan&rsquo;s Hearth</h2></div>
    <ul class="features">
      <li><h3>Locally sourced flour and dairy</h3><p>We partner with Gauteng farmers and mills so every ingredient is fresh, traceable and kind to the community.</p></li>
      <li><h3>Traditional long fermentation</h3><p>Our bread rests overnight. The slow ferment builds flavour, keeps the crumb open and makes the bread easier to digest.</p></li>
      <li><h3>Made with love, baked daily</h3><p>Nothing is frozen or shipped in. Every loaf and pastry is shaped by a baker you can meet at the counter.</p></li>
    </ul>
  </div>
</section>

<section class="section" aria-labelledby="featured-title">
  <div class="wrap">
    <div class="section-head"><div><h2 id="featured-title">Our best-loved bakes</h2><p>Sourdough, croissants and cakes that locals come back for.</p></div><a class="btn btn--ghost" href="products.html">See all products</a></div>
    <ul class="card-grid">{"".join(product_card(p) for p in featured)}</ul>
  </div>
</section>

<section class="section section--tint" aria-labelledby="journal-title">
  <div class="wrap">
    <div class="section-head"><div><h2 id="journal-title">Baker&rsquo;s notes</h2><p>Short stories from the bench: craft, cakes and community.</p></div></div>
    <div class="notes" id="journal-list"></div>
    <noscript><p>Baker&rsquo;s notes need JavaScript. Visit our <a href="products.html">products</a> or <a href="contact.html">contact us</a> instead.</p></noscript>
    <p class="center"><button type="button" class="btn btn--ghost" id="journal-more">Load more notes</button></p>
  </div>
</section>

<section class="section" aria-labelledby="cta-title">
  <div class="wrap split split--even">
    <div>
      <h2 id="cta-title">Planning a celebration or stocking a cafe?</h2>
      <p style="margin-block:1rem 1.5rem">Tell us what you need, how many people it should feed and when. We reply with a price and collection date within one business day.</p>
      <p><a class="btn" href="enquiry.html">Start an enquiry</a> <a class="btn btn--ghost" href="contact.html">Find us on the map</a></p>
    </div>
    <div class="split__media">{img_tag("chocolate-ganache-celebration-cake", "Chocolate celebration cake with dripping ganache and buttercream swirls", "(max-width: 960px) 92vw, 520px")}</div>
  </div>
</section>
</main>
"""
PAGES["index.html"] = dict(
    file="index.html", name="Home",
    title="Artisan Bakery in Pretoria | Sourdough, Croissants & Cakes",
    description="Fresh sourdough, butter croissants and custom celebration cakes baked daily at Artisan's Hearth Bakery, Pretoria. Order online and collect in store.",
    keywords="artisan bakery Pretoria, sourdough bread Pretoria, fresh bread Pretoria, croissants Pretoria, custom celebration cakes Pretoria, handmade bakery Gauteng",
    ld=[BAKERY_LD, {"@context": "https://schema.org", "@type": "WebSite", "name": "Artisan's Hearth Bakery", "url": SITE_URL}],
    body=home_body, scripts="")

# ---------------- ABOUT -----------------------------------------------------------
team_html = "".join(
    f'<li><div class="avatar" aria-hidden="true">{"".join(w[0] for w in m["name"].split()[:2])}</div><h3>{e(m["name"])}</h3><p class="role">{e(m["role"])}</p><p>{e(m["bio"])}</p></li>'
    for m in data["team"])


def acc(id_, q, a, open_=False):
    return f"""<div class="accordion__item"><h3 class="accordion__heading"><button type="button" class="accordion__trigger" id="{id_}-t" aria-expanded="{"true" if open_ else "false"}" aria-controls="{id_}-p">{q}<span class="accordion__icon" aria-hidden="true"></span></button></h3>
<div class="accordion__panel" id="{id_}-p" role="region" aria-labelledby="{id_}-t"><div class="accordion__inner">{a}</div></div></div>"""


ABOUT_FAQ = [
    ("Why is your sourdough so sour and so open?", "Our starter is ten years old and our dough ferments for up to 24 hours. A long, cool ferment develops flavour and gives the airy, open crumb."),
    ("Which flour do you use?", "Stone-ground wheat and rye from Gauteng mills. We pick them for flavour, not price, and we know the farmers by name."),
    ("Do you make vegan or dairy-free bread?", "Yes. Our sourdough and dark rye are vegan. Pastries and cakes contain butter, milk and eggs. Ask about allergens on the product pages."),
    ("Can I visit the bakery floor?", "Small groups can join a Saturday-morning tour at 8:30 am. Send us an enquiry to reserve a place."),
]
about_body = f"""<main id="main">
{page_hero("About Artisan&rsquo;s Hearth Bakery", "A neighbourhood artisan bakery in Pretoria, baking by hand since 2016.", [("index.html", "Home"), ("about.html", "About")])}
<section class="section" aria-labelledby="story-title">
  <div class="wrap split">
    <div>
      <h2 id="story-title">Our story</h2>
      <p style="margin-top:1rem">Artisan&rsquo;s Hearth Bakery was founded in 2016 by master baker Lethabo Letshwiti. After years of training in traditional European bakeries, Lethabo came home to South Africa with one idea: to bring authentic, handcrafted bread to the neighbourhood.</p>
      <p style="margin-top:1rem">What began as a small home bakery has grown into a loved Pretoria institution known for quality, tradition and community. Every batch is still made by hand, to recipes perfected over many years.</p>
    </div>
    <div class="split__media">{img_tag("sourdough-loaf-torn-open-crumb", "Hands tearing open a golden sourdough loaf to show its airy, open crumb", "(max-width: 960px) 92vw, 480px")}</div>
  </div>
</section>

<section class="section section--tint" aria-labelledby="guide-title">
  <div class="wrap">
    <h2 id="guide-title" style="margin-bottom:1.5rem">What we stand for</h2>
    <div class="tabs" data-tabs>
      <div role="tablist" aria-label="Mission, vision and values">
        <button role="tab" id="tab-mission" aria-controls="panel-mission" aria-selected="true">Mission</button>
        <button role="tab" id="tab-vision" aria-controls="panel-vision" aria-selected="false" tabindex="-1">Vision</button>
        <button role="tab" id="tab-values" aria-controls="panel-values" aria-selected="false" tabindex="-1">Values</button>
      </div>
      <div role="tabpanel" id="panel-mission" aria-labelledby="tab-mission"><p class="lede">To bring the joy of authentic, handcrafted bread and pastries to our community, using the finest local ingredients and time-honoured techniques.</p></div>
      <div role="tabpanel" id="panel-vision" aria-labelledby="tab-vision" hidden><p class="lede">To be a beloved community hub where the simple pleasure of good food is shared and celebrated.</p></div>
      <div role="tabpanel" id="panel-values" aria-labelledby="tab-values" hidden>
        <ul class="values">
          <li><strong>Quality</strong><br>Only the finest ingredients and traditional methods.</li>
          <li><strong>Community</strong><br>Supporting local farmers and building connections.</li>
          <li><strong>Tradition</strong><br>Honouring time-honoured artisan baking techniques.</li>
          <li><strong>Passion</strong><br>Every loaf crafted with love and dedication.</li>
          <li><strong>Sustainability</strong><br>Minimising waste and sourcing responsibly.</li>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="timeline-title">
  <div class="wrap split split--even">
    <div>
      <h2 id="timeline-title" style="margin-bottom:1.5rem">Ten years of baking</h2>
      <ol class="timeline">
        <li><strong>2016</strong><p>The first loaf leaves a home oven and the sourdough starter is born.</p></li>
        <li><strong>2018</strong><p>We open our first shopfront on Main Street, Pretoria.</p></li>
        <li><strong>2021</strong><p>Wholesale deliveries begin for local cafes and restaurants.</p></li>
        <li><strong>2024</strong><p>Custom celebration cakes join the menu.</p></li>
        <li><strong>Today</strong><p>Four bakers, six days a week, and the same ten-year-old starter.</p></li>
      </ol>
    </div>
    <div>
      <h2 style="margin-bottom:1rem">Questions we hear a lot</h2>
      <div class="accordion" data-accordion data-single>
        {"".join(acc(f"faq{i}", q, f"<p>{a}</p>", i == 0) for i, (q, a) in enumerate(ABOUT_FAQ))}
      </div>
    </div>
  </div>
</section>

<section class="section section--tint" aria-labelledby="team-title">
  <div class="wrap">
    <h2 id="team-title" style="margin-bottom:1.5rem">Meet our team</h2>
    <ul class="team">{team_html}</ul>
  </div>
</section>
</main>
"""
PAGES["about.html"] = dict(
    file="about.html", name="About",
    title="About Us | Handmade Artisan Bakery Team in Pretoria",
    description="Meet the bakers behind Artisan's Hearth Bakery in Pretoria. Our story, mission, values and the slow-fermentation methods behind our sourdough and pastries.",
    keywords="about Artisan's Hearth Bakery, Pretoria bakers, artisan baking story, local flour bakery, traditional bread methods, bakery team Pretoria",
    ld=[breadcrumb_ld("About", "about.html"), {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in ABOUT_FAQ]}],
    body=about_body, scripts="")

# ---------------- PRODUCTS --------------------------------------------------------
noscript_list = "".join(f'<li>{e(p["name"])}: {rand(p["price"])} ({e(p["unit"])}). {e(p["short"])}</li>' for p in PRODUCTS)
PROD_FAQ = [
    ("How much notice do you need?", "Breads and pastries need one day&rsquo;s notice for guaranteed availability. Celebration cakes need 48 hours."),
    ("Do you deliver?", "We deliver wholesale orders daily around Pretoria. Retail delivery is available on request for orders over R500."),
    ("Can I change a cake flavour or add a message?", "Yes. Tell us the flavour, size, colours and message in your enquiry and we will confirm the details with a price."),
    ("How do I store sourdough?", "Keep it cut-side down on a board for two days, then slice and freeze. Refresh in a hot oven for five minutes."),
]
products_body = f"""<main id="main">
{page_hero("Our fresh bakery products", "Artisan breads, flaky pastries and celebration cakes, baked fresh daily in Pretoria.", [("index.html", "Home"), ("products.html", "Products")])}
<section class="section" aria-labelledby="listing-title">
  <div class="wrap">
    <h2 id="listing-title" class="sr-only">Product listing</h2>
    <div class="toolbar" role="search" aria-label="Search and filter products">
      <div class="field"><label for="product-search">Search products</label><input type="search" id="product-search" name="q" placeholder="Try sourdough, croissant or chocolate" autocomplete="off" maxlength="60"></div>
      <div class="field"><label for="product-sort">Sort by</label><select id="product-sort"><option value="featured">Featured first</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option><option value="name">Name: A to Z</option></select></div>
      <div class="field"><span class="label">Enquiry list</span><a class="btn btn--ghost btn--small" href="enquiry.html">View list <span class="badge" data-basket-count hidden>0</span></a></div>
    </div>
    <div class="chips" id="category-chips" role="group" aria-label="Filter by category"></div>
    <div class="results-line"><p id="results-count" aria-hidden="true">Loading products&hellip;</p><p id="results-live" class="sr-only" role="status" aria-live="polite"></p></div>
    <ul class="card-grid" id="product-grid"></ul>
    <div class="empty" id="product-empty" hidden><h3>Nothing matches your search</h3><p>Try a shorter word like &ldquo;bread&rdquo;, check the spelling, or clear your filters.</p><button type="button" class="btn" id="reset-filters">Clear filters</button></div>
    <noscript><ul>{noscript_list}</ul></noscript>
  </div>
</section>

<section class="section section--tint" aria-labelledby="wholesale-title">
  <div class="wrap split split--even">
    <div>
      <h2 id="wholesale-title">Wholesale bread for Pretoria cafes and restaurants</h2>
      <ul style="margin:1rem 0 1.5rem 1.2rem">
        <li>Daily delivery before you open</li>
        <li>Custom loaf sizes and packaging</li>
        <li>10% off weekly orders over R1&nbsp;500, 15% over R4&nbsp;000</li>
      </ul>
      <a class="btn" href="enquiry.html?product=wholesale">Enquire about wholesale</a>
    </div>
    <div>
      <h2 style="margin-bottom:1rem">Ordering questions</h2>
      <div class="accordion" data-accordion data-single>
        {"".join(acc(f"pf{i}", q, f"<p>{a}</p>", i == 0) for i, (q, a) in enumerate(PROD_FAQ))}
      </div>
    </div>
  </div>
</section>

<dialog id="product-dialog" aria-labelledby="dialog-title" style="max-width:min(56rem,94vw);width:100%;border:0;border-radius:12px;padding:0;background:var(--flour);color:var(--ink)">
  <div style="display:flex;justify-content:flex-end;padding:.6rem .8rem 0"><button type="button" class="btn btn--ghost btn--small" data-dialog-close>Close</button></div>
  <div id="product-dialog-body" style="padding:0 1.5rem 1.5rem"></div>
</dialog>
</main>
"""
products_ld = [breadcrumb_ld("Products", "products.html"), {
    "@context": "https://schema.org", "@type": "ItemList", "name": "Artisan's Hearth Bakery products",
    "itemListElement": [{"@type": "ListItem", "position": i + 1, "item": {
        "@type": "Product", "name": p["name"], "description": p["short"], "image": f'{SITE_URL}images/{p["img"]}-{p.get("w", 400)}.webp' if False else f'{SITE_URL}images/{p["img"]}-400.webp',
        "brand": {"@type": "Brand", "name": "Artisan's Hearth Bakery"},
        "offers": {"@type": "Offer", "price": f'{p["price"]:.2f}', "priceCurrency": "ZAR", "availability": "https://schema.org/InStock", "url": SITE_URL + "products.html"}}}
        for i, p in enumerate(PRODUCTS)]},
    {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": html.unescape(q), "acceptedAnswer": {"@type": "Answer", "text": html.unescape(a.replace("&rsquo;", "’"))}} for q, a in PROD_FAQ]}]
PAGES["products.html"] = dict(
    file="products.html", name="Products",
    title="Bakery Products & Prices | Bread, Pastries, Cakes Pretoria",
    description="Browse sourdough, rye, croissants and celebration cakes from Artisan's Hearth Bakery in Pretoria. Search, filter and add items to your enquiry. Prices in rand.",
    keywords="sourdough bread price, buy croissants Pretoria, celebration cakes Pretoria, wholesale bread Pretoria, bakery products South Africa, chocolate ganache cake, dark rye bread",
    ld=products_ld, body=products_body, scripts='<script src="js/products.js"></script>')

# ---------------- GALLERY ---------------------------------------------------------
gallery_body = f"""<main id="main">
{page_hero("Bakery photo gallery", "A look at the loaves, laminated pastry and cakes that come out of our Pretoria oven. Tap a photo to see it larger.", [("index.html", "Home"), ("gallery.html", "Gallery")])}
<section class="section" aria-labelledby="gallery-title">
  <div class="wrap">
    <h2 id="gallery-title" class="sr-only">Photos</h2>
    <div class="chips" id="gallery-chips" role="group" aria-label="Filter photos"></div>
    <p id="gallery-live" class="sr-only" role="status" aria-live="polite"></p>
    <div class="gallery" id="gallery-grid"></div>
    <noscript><p>The gallery viewer needs JavaScript. Browse the photos on the <a href="products.html">products page</a>.</p></noscript>
  </div>
</section>
<div class="lightbox" id="lightbox" role="dialog" aria-modal="true" aria-labelledby="lightbox-title" aria-hidden="true">
  <div class="lightbox__top"><p class="lightbox__count" id="lightbox-count" aria-live="polite"></p><button type="button" class="lightbox__btn lightbox__close" aria-label="Close larger view">&times;</button></div>
  <div class="lightbox__stage">
    <button type="button" class="lightbox__btn lightbox__prev" aria-label="Previous photo">&lsaquo;</button>
    <img class="lightbox__img" id="lightbox-img" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" alt="">
    <button type="button" class="lightbox__btn lightbox__next" aria-label="Next photo">&rsaquo;</button>
  </div>
  <div class="lightbox__caption"><h2 id="lightbox-title"></h2><p id="lightbox-caption"></p></div>
</div>
</main>
"""
PAGES["gallery.html"] = dict(
    file="gallery.html", name="Gallery",
    title="Photo Gallery | Fresh Bread & Cakes at Artisan's Hearth",
    description="See our sourdough, rye, croissants and celebration cakes up close. Tap any photo from Artisan's Hearth Bakery in Pretoria to view it larger.",
    keywords="bakery photos Pretoria, sourdough bread photos, croissant layers, celebration cake gallery, artisan bakery gallery, handmade pastry images",
    ld=[breadcrumb_ld("Gallery", "gallery.html"), {
        "@context": "https://schema.org", "@type": "ImageGallery", "name": "Artisan's Hearth Bakery gallery",
        "image": [{"@type": "ImageObject", "contentUrl": f'{SITE_URL}images/{g["img"]}-400.webp', "name": g["title"], "description": g["alt"]} for g in data["gallery"]]}],
    body=gallery_body, scripts='<script src="js/gallery.js"></script>')

# ---------------- ENQUIRY ---------------------------------------------------------
enquiry_body = f"""<main id="main">
{page_hero("Place an enquiry", "Ask about a wholesale account, a custom celebration cake or any product. You get an estimate and a collection date straight away.", [("index.html", "Home"), ("enquiry.html", "Enquiry")])}
<section class="section" aria-labelledby="form-title">
  <div class="wrap form-layout">
    <div class="form-card">
      <h2 id="form-title" style="margin-bottom:.4rem">Tell us what you need</h2>
      <p class="hint" style="margin-bottom:1.25rem">Fields marked <span class="req" aria-hidden="true">*</span><span class="sr-only">with an asterisk</span> are required.</p>
      <form id="enquiry-form" action="enquiry.html" method="post" aria-labelledby="form-title">
        <div class="form-summary" tabindex="-1"></div>
        <div class="form-grid">
          <div class="field"><label for="name">Full name <span class="req" aria-hidden="true">*</span></label><input type="text" id="name" name="name" autocomplete="name" required maxlength="60" aria-describedby="name-err"><p class="field-error" id="name-err"></p></div>
          <div class="field"><label for="email">Email address <span class="req" aria-hidden="true">*</span></label><input type="email" id="email" name="email" autocomplete="email" required maxlength="254" aria-describedby="email-err"><p class="field-error" id="email-err"></p></div>
          <div class="field"><label for="phone">Phone number</label><input type="tel" id="phone" name="phone" autocomplete="tel" inputmode="tel" placeholder="082 123 4567" aria-describedby="phone-hint phone-err"><p class="hint" id="phone-hint">Needed if you want a call or WhatsApp reply.</p><p class="field-error" id="phone-err"></p></div>
          <div class="field"><label for="enquiry-type">Enquiry type <span class="req" aria-hidden="true">*</span></label>
            <select id="enquiry-type" name="enquiry_type" required aria-describedby="enquiry-type-err">
              <option value="">Select a type</option><option value="wholesale">Wholesale account</option><option value="custom-order">Custom or celebration cake</option><option value="general">General question</option><option value="feedback">Feedback</option>
            </select><p class="field-error" id="enquiry-type-err"></p></div>
          <div class="field"><label for="product-interest">Product of interest</label><select id="product-interest" name="product_interest" aria-describedby="pi-hint"></select><p class="hint" id="pi-hint">Optional. We use it to work out your estimate.</p></div>
          <div class="field"><label for="quantity">Quantity</label><input type="number" id="quantity" name="quantity" min="1" max="500" step="1" inputmode="numeric" placeholder="1" aria-describedby="quantity-err"><p class="field-error" id="quantity-err"></p></div>
          <div class="field full"><label for="needed-by">Date needed</label><input type="date" id="needed-by" name="needed_by" aria-describedby="date-hint needed-by-err"><p class="hint" id="date-hint"></p><p class="field-error" id="needed-by-err"></p></div>
          <div class="field full"><label for="message">Your message <span class="req" aria-hidden="true">*</span></label><textarea id="message" name="message" required maxlength="800" placeholder="Flavour, number of guests, delivery or collection, allergies&hellip;" aria-describedby="message-err message-count"></textarea><div class="counter" id="message-count" aria-hidden="true">0 / 800</div><p class="field-error" id="message-err"></p></div>
          <fieldset class="field full" aria-describedby="contact_method-err"><legend>How should we reply? <span class="req" aria-hidden="true">*</span></legend>
            <div class="choice-row">
              <label class="choice"><input type="radio" name="contact_method" value="email" checked> Email</label>
              <label class="choice"><input type="radio" name="contact_method" value="phone"> Phone call</label>
              <label class="choice"><input type="radio" name="contact_method" value="whatsapp"> WhatsApp</label>
            </div><p class="field-error" id="contact_method-err"></p></fieldset>
          <div class="field full"><label class="choice"><input type="checkbox" name="newsletter" value="yes"> Send me seasonal menus and offers (optional)</label></div>
          <div class="field full"><label class="choice"><input type="checkbox" name="consent" id="consent" aria-describedby="consent-err"> I agree that Artisan&rsquo;s Hearth may store my details to reply to this enquiry. <span class="req" aria-hidden="true">*</span></label><p class="field-error" id="consent-err"></p></div>
          <div class="hp" aria-hidden="true"><label for="website">Leave this field empty</label><input type="text" id="website" name="website" tabindex="-1" autocomplete="off"></div>
        </div>
        <div class="form-actions"><button type="submit" class="btn">Send enquiry</button><button type="reset" class="btn btn--ghost">Clear form</button></div>
      </form>
      <div class="response" id="enquiry-response" role="region" aria-label="Enquiry response" aria-live="polite"></div>
    </div>
    <aside>
      <div class="quote-box" aria-labelledby="quote-title"><h2 id="quote-title" style="font-size:1.25rem;margin-bottom:.75rem">Your enquiry list</h2><div id="quote-body"></div></div>
      <div class="quote-box" style="margin-top:1.25rem"><h2 style="font-size:1.25rem;margin-bottom:.75rem">Other ways to reach us</h2>
        <ul class="info-list">
          <li><h3>Phone</h3><a href="{CFG["phoneHref"]}">{CFG["phone"]}</a></li>
          <li><h3>Email</h3><a href="mailto:{CFG["email"]}">{CFG["email"]}</a></li>
          <li><h3>Visit</h3>123 Main Street, Pretoria<br>Mon&ndash;Fri 7:00&ndash;18:00, Sat 8:00&ndash;16:00</li>
        </ul>
      </div>
    </aside>
  </div>
</section>
</main>
"""
PAGES["enquiry.html"] = dict(
    file="enquiry.html", name="Enquiry",
    title="Order Enquiry & Quote | Wholesale & Custom Cakes Pretoria",
    description="Request a quote for wholesale bread or a custom celebration cake from Artisan's Hearth Bakery in Pretoria. Get an instant estimate and collection date.",
    keywords="bakery enquiry Pretoria, custom cake quote, wholesale bread quote Pretoria, order celebration cake, bakery order form, cake order Pretoria",
    ld=[breadcrumb_ld("Enquiry", "enquiry.html")], body=enquiry_body, scripts='<script src="js/forms.js"></script>')

# ---------------- CONTACT ---------------------------------------------------------
hours_rows = "".join(
    f'<tr data-day="{d}"><th scope="row">{n}</th><td>{t}</td></tr>' for d, n, t in
    [(1, "Monday", "7:00 am &ndash; 6:00 pm"), (2, "Tuesday", "7:00 am &ndash; 6:00 pm"), (3, "Wednesday", "7:00 am &ndash; 6:00 pm"),
     (4, "Thursday", "7:00 am &ndash; 6:00 pm"), (5, "Friday", "7:00 am &ndash; 6:00 pm"), (6, "Saturday", "8:00 am &ndash; 4:00 pm"), (0, "Sunday", "Closed")])
contact_body = f"""<main id="main">
{page_hero("Contact us", "Questions, compliments or a custom order? Send us a message, call, or come and say hello in Pretoria.", [("index.html", "Home"), ("contact.html", "Contact")])}
<section class="section" aria-labelledby="touch-title">
  <div class="wrap form-layout">
    <div class="form-card">
      <h2 id="touch-title" style="margin-bottom:.4rem">Send us a message</h2>
      <p class="hint" style="margin-bottom:1.25rem">We turn your message into an email addressed to <strong>{CFG["email"]}</strong>. You then send it from your own email app. Fields marked <span class="req" aria-hidden="true">*</span><span class="sr-only">with an asterisk</span> are required.</p>
      <form id="contact-form" action="contact.html" method="post" aria-labelledby="touch-title">
        <div class="form-summary" tabindex="-1"></div>
        <div class="form-grid">
          <div class="field"><label for="c-name">Your name <span class="req" aria-hidden="true">*</span></label><input type="text" id="c-name" name="name" autocomplete="name" required maxlength="60" aria-describedby="name-err"><p class="field-error" id="name-err"></p></div>
          <div class="field"><label for="c-email">Email address <span class="req" aria-hidden="true">*</span></label><input type="email" id="c-email" name="email" autocomplete="email" required maxlength="254" aria-describedby="email-err"><p class="field-error" id="email-err"></p></div>
          <div class="field"><label for="c-phone">Phone number</label><input type="tel" id="c-phone" name="phone" autocomplete="tel" inputmode="tel" placeholder="082 123 4567" aria-describedby="phone-err"><p class="field-error" id="phone-err"></p></div>
          <div class="field"><label for="c-type">Type of message <span class="req" aria-hidden="true">*</span></label>
            <select id="c-type" name="message_type" required aria-describedby="type-err"><option value="">Select a type</option><option value="question">Question about products</option><option value="order">Order or collection</option><option value="event">Event or catering</option><option value="feedback">Feedback or compliment</option><option value="complaint">Complaint</option><option value="press">Press or partnerships</option><option value="job">Work with us</option><option value="other">Something else</option></select><p class="field-error" id="type-err"></p></div>
          <div class="field full"><label for="c-subject">Subject <span class="req" aria-hidden="true">*</span></label><input type="text" id="c-subject" name="subject" required maxlength="100" placeholder="What is this about?" aria-describedby="subject-err"><p class="field-error" id="subject-err"></p></div>
          <div class="field full"><label for="c-message">Message <span class="req" aria-hidden="true">*</span></label><textarea id="c-message" name="message" required maxlength="1000" aria-describedby="msg-err c-message-count"></textarea><div class="counter" id="c-message-count" aria-hidden="true">0 / 1000</div><p class="field-error" id="msg-err"></p></div>
          <div class="field full"><label class="choice"><input type="checkbox" name="consent" id="c-consent" aria-describedby="consent-err"> I agree that Artisan&rsquo;s Hearth may use these details to reply to me. <span class="req" aria-hidden="true">*</span></label><p class="field-error" id="consent-err"></p></div>
          <div class="hp" aria-hidden="true"><label for="c-website">Leave this field empty</label><input type="text" id="c-website" name="website" tabindex="-1" autocomplete="off"></div>
        </div>
        <div class="form-actions"><button type="submit" class="btn">Prepare my email</button><button type="reset" class="btn btn--ghost">Clear form</button></div>
      </form>
      <div class="response" id="contact-response" role="region" aria-label="Email ready to send" aria-live="polite"></div>
    </div>
    <aside>
      <div class="quote-box"><h2 style="font-size:1.25rem;margin-bottom:.75rem">Get in touch</h2>
        <ul class="info-list">
          <li><h3>Address</h3><address>123 Main Street<br>Pretoria, Gauteng<br>0001, South Africa</address></li>
          <li><h3>Phone</h3><a href="{CFG["phoneHref"]}">{CFG["phone"]}</a></li>
          <li><h3>Email</h3><a href="mailto:{CFG["email"]}">{CFG["email"]}</a></li>
          <li><h3>Social media</h3><a href="https://www.facebook.com/artisanshearthbakery" target="_blank" rel="noopener noreferrer">Facebook</a> &middot; <a href="https://www.instagram.com/artisanshearthbakery" target="_blank" rel="noopener noreferrer">Instagram</a> &middot; <a href="https://wa.me/27123456789" target="_blank" rel="noopener noreferrer">WhatsApp</a></li>
        </ul>
      </div>
    </aside>
  </div>
</section>

<section class="section section--tint" aria-labelledby="visit-title">
  <div class="wrap">
    <h2 id="visit-title" style="margin-bottom:1.5rem">Visiting the bakery</h2>
    <div class="tabs" data-tabs>
      <div role="tablist" aria-label="Visitor information">
        <button role="tab" id="tab-hours" aria-controls="panel-hours" aria-selected="true">Opening hours</button>
        <button role="tab" id="tab-travel" aria-controls="panel-travel" aria-selected="false" tabindex="-1">Getting here</button>
        <button role="tab" id="tab-parking" aria-controls="panel-parking" aria-selected="false" tabindex="-1">Parking</button>
      </div>
      <div role="tabpanel" id="panel-hours" aria-labelledby="tab-hours">
        <table class="hours"><caption class="sr-only">Opening hours</caption><tbody>{hours_rows}</tbody></table>
        <p class="hint" style="margin-top:.75rem">Closed on South African public holidays. Today&rsquo;s row is highlighted.</p>
      </div>
      <div role="tabpanel" id="panel-travel" aria-labelledby="tab-travel" hidden>
        <h3 style="margin-bottom:.5rem">By car</h3><p>We are on Main Street, just off the N1. Take the Main Street exit and travel east for about 2 km.</p>
        <h3 style="margin:1rem 0 .5rem">By public transport</h3><p>The nearest bus stop is 200 m from our door on Main Street. Several taxi routes also pass nearby.</p>
      </div>
      <div role="tabpanel" id="panel-parking" aria-labelledby="tab-parking" hidden>
        <p>We have a small customer car park, with extra street parking close by. Early mornings and Saturday afternoons are the quietest.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="map-title">
  <div class="wrap">
    <div class="section-head"><div><h2 id="map-title">Find our Pretoria bakery</h2><p>Drag to explore, zoom with the buttons, or see how far you are from the oven.</p></div></div>
    <div class="map-shell">
      <div class="map-panel">
        <h3>Artisan&rsquo;s Hearth Bakery</h3>
        <p>123 Main Street, Pretoria, Gauteng, 0001. Limited parking on site.</p>
        <button type="button" class="btn" id="locate-btn">Show my distance</button>
        <a class="btn btn--ghost" id="directions-link" href="https://www.google.com/maps" target="_blank" rel="noopener noreferrer">Get directions</a>
        <p class="map-result" id="map-result" role="status" hidden></p>
      </div>
      <div id="bakery-map" role="region" aria-label="Map showing the location of Artisan's Hearth Bakery"><noscript><p class="map-fallback">The map needs JavaScript. We are at 123 Main Street, Pretoria.</p></noscript></div>
    </div>
  </div>
</section>
</main>
"""
PAGES["contact.html"] = dict(
    file="contact.html", name="Contact",
    title="Contact & Map | Artisan's Hearth Bakery Pretoria",
    description="Visit or contact Artisan's Hearth Bakery at 123 Main Street, Pretoria. Opening hours, directions, interactive map and a quick message form.",
    keywords="bakery Pretoria contact, Artisan's Hearth address, bakery opening hours Pretoria, bakery near me Pretoria, directions bakery Main Street",
    ld=[BAKERY_LD, breadcrumb_ld("Contact", "contact.html")], body=contact_body, scripts='<script src="js/forms.js"></script>\n<script src="js/map.js"></script>')

# ---------------- 404 -------------------------------------------------------------
PAGES["404.html"] = dict(
    file="404.html", name="Not found", title="Page Not Found | Artisan's Hearth Bakery",
    description="That page could not be found. Return to the Artisan's Hearth Bakery home page or browse our fresh bread, pastries and cakes.",
    keywords="page not found", robots="noindex, follow", ld=[],
    body="""<main id="main"><section class="section"><div class="wrap not-found"><h1>This page has gone stale</h1><p class="lede">We could not find the page you asked for. It may have moved, or the address may have a typo.</p><p><a class="btn" href="index.html">Back to the home page</a> <a class="btn btn--ghost" href="products.html">See our products</a></p></div></section></main>""",
    scripts="")

# ---- Write -----------------------------------------------------------------------
for fname, pg in PAGES.items():
    out = head(pg) + header(fname) + pg["body"] + footer(pg["scripts"])
    (ROOT / fname).write_text(out, encoding="utf-8")
    print("wrote", fname, len(out))

# ---- sitemap.xml + robots.txt ------------------------------------------------------
urls = [("index.html", "1.0", "weekly"), ("products.html", "0.9", "weekly"), ("about.html", "0.7", "monthly"),
        ("gallery.html", "0.6", "monthly"), ("enquiry.html", "0.8", "monthly"), ("contact.html", "0.8", "monthly")]
sm = ['<?xml version="1.0" encoding="UTF-8"?>',
      '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">']
for f, pr, fr in urls:
    loc = SITE_URL if f == "index.html" else SITE_URL + f
    extra = ""
    if f == "products.html":
        extra = "".join(f"<image:image><image:loc>{SITE_URL}images/{p['img']}-400.webp</image:loc><image:title>{e(p['name'])}</image:title></image:image>" for p in PRODUCTS)
    if f == "gallery.html":
        extra = "".join(f"<image:image><image:loc>{SITE_URL}images/{g['img']}-400.webp</image:loc><image:title>{e(g['title'])}</image:title></image:image>" for g in data["gallery"])
    sm.append(f"  <url><loc>{loc}</loc><lastmod>{TODAY}</lastmod><changefreq>{fr}</changefreq><priority>{pr}</priority>{extra}</url>")
sm.append("</urlset>")
(ROOT / "sitemap.xml").write_text("\n".join(sm) + "\n", encoding="utf-8")
(ROOT / "robots.txt").write_text(
    "# robots.txt for Artisan's Hearth Bakery\nUser-agent: *\nAllow: /\nDisallow: /tools/\nDisallow: /screenshots/\nDisallow: /404.html\n\n"
    f"Sitemap: {SITE_URL}sitemap.xml\n", encoding="utf-8")
print("site url:", SITE_URL)
